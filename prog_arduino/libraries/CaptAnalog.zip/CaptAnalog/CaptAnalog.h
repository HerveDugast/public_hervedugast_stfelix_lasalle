#pragma once
/*-------------------------------------------------------------------------------------------------
Classe : CaptAnalog.h      Version : 3.0           Version arduino : 1.6.5
Auteur : H. Dugast         Date : 20-04-2015
Fonction résumée :
- convertit la grandeur analogique (tension) sortant du capteur et entrant dans le
convertisseur analogique/numérique (CAN) :
• en code numérique proportionnel : 0 à 1023
• en pourcentage par rapport à la pleine échelle (0 à 5V -> 0 à 100 %)
- prépare la durée entre 2 mesures du "capteur" en calculant le nombre de baseTemps nécessaire
Exemple de capteur analogique : potentiomètre

------------------------------------------------------------------------------------------------ */
#include <Arduino.h>

class CaptAnalog
{
public:
   // Constructeur, pour préparer un objet de type capteur analogique (comme un potentiomètre)
   CaptAnalog(uint8_t pinCaptAnalog, unsigned long intervalMesure);

   // Calcule le code correspondant au signal de sortie du capteur. 
   // Entrée CAN : 0 à 5V --> Sortie CAN : 0 à 1023
   uint16_t convertirEnCodeNumerique();

   // Calcule en pourcentage la valeur de la tension de sortie du capteur par rapport à la pleine
   // échelle. Entrée CAN : 0 à 5V --> Sortie CAN : 0 à 100 %
   uint8_t convertirEnPourcentage();

   // Debug : affiche le contenu des variables de l'objet
   // Nécessite l'initialisation de la liaison série 0 dans le setup() :  Serial.begin(115200);
   void afficherVariableMembre();

   // Retourne durée entre 2 mesures du signal sortant du capteur en ms
   uint16_t getIntervalConversion() {return m_intervalConversion;}
   // Retourne code proportionnel au signal de sortie du capteur (sortie CAN 10 bits : 0 à 1023)
   uint16_t getCodeCan() {return m_codeCan;}
   // pourcentage du signal de sortie du capteur par rapport à pleine échelle (0 à 5V -> 0 à 100 %)
   uint8_t getCodeCanPourcent() {return m_codeCanPourcent;}
   // indique si une conversion vient d'être effectuée
   bool isConversionEffectue() { return m_conversionEffectue; }
   // remet à 0 le drapeau signalant qu'une conversion venait d'être effectuée
   void resetConversionEffectue() { m_conversionEffectue = 0; }


protected:
   // numéro de la broche qui est connectée au capteur analogique
   uint8_t m_pinCaptAnalog;
   // durée entre 2 mesures du signal sortant du capteur en ms
   unsigned long m_intervalConversion;
   // code proportionnel au signal de sortie du capteur (sortie CAN 10 bits : 0 à 1023)
   uint16_t m_codeCan;
   // pourcentage du signal de sortie du capteur par rapport à pleine échelle (0 à 5V -> 0 à 100 %)
   uint8_t m_codeCanPourcent;
   // signale qu'une conversion vient d'être effectuée
   bool m_conversionEffectue;

private:
   // Calcule le code numérique proportionnellement au signal de sortie du capteur.
   void convertirEnCodeNumeriqueNow();
};

