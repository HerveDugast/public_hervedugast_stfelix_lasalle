/*-------------------------------------------------------------------------------------------------
Classe : CaptAnalog.cpp       Version : 3.0           Version arduino : 1.6.5
Auteur : H. Dugast            Date : 20-04-2016
Fonction résumée : 
   - convertit la grandeur analogique (tension) sortant du capteur et entrant dans le  
     convertisseur analogique/numérique (CAN) :
         • en code numérique proportionnel : 0 à 1023 
         • en pourcentage par rapport à la pleine échelle (0 à 5V -> 0 à 100 %)
   - prépare la durée entre 2 mesures du "capteur" en calculant le nombre de baseTemps nécessaire
   Exemple de capteur analogique : potentiomètre
 ----------------------------------------------------------------------------------------------- */
#include <CaptAnalog.h>

// ------------------------------------------------------------------------------------------------
// Public : Constructeur, prépare un objet CaptAnalog
// Paramètres :
//    pinCaptAnalog  -> numéro de broche connectée au potentiomètre
//    intervalMesure -> durée entre 2 mesures du signal sortant du capteur en ms
// ------------------------------------------------------------------------------------------------
CaptAnalog::CaptAnalog(uint8_t pinCaptAnalog, unsigned long intervalConversion):
   m_pinCaptAnalog(pinCaptAnalog), m_intervalConversion(intervalConversion)
{
   pinMode(m_pinCaptAnalog, INPUT); // configure la broche pinCaptAnalog en ENTREE
   // code proportionnel au signal de sortie du capteur (CAN 10 bits : 0 à 1023)
   convertirEnCodeNumerique();    
   // pourcentage pleine échelle (0 à 5V -> 0 à 100 %)
   convertirEnPourcentage();
   m_conversionEffectue = 0;
}

//-------------------------------------------------------------------------------------------------
// Calcule le code numérique proportionnellement au signal de sortie du capteur.
// Le convertisseur analogique/numérique (CAN 10 bits) convertit la grandeur analogique d'entrée, 
// variant de 0 à 5V, en un code numérique proportionnel à celle-ci soit de 0 à 1023.
// Retour :
//    int -> code entre 0 et 1023 proportionnel à la grandeur analogique d'entrée
//             Entrée CAN : 0 à 5V --> Sortie CAN : 0 à 1023
//-------------------------------------------------------------------------------------------------
void CaptAnalog::convertirEnCodeNumeriqueNow()
{
   m_codeCan = analogRead(m_pinCaptAnalog); // code numérique proportionnel à tension entrée
}

//-------------------------------------------------------------------------------------------------
// Calcule en pourcentage la valeur de la tension de sortie du capteur par rapport à la pleine
// échelle. Le convertisseur analogique/numérique (CAN 10 bits) convertit la grandeur analogique 
// d'entrée, variant de 0 à 5V, en code soit de 0 à 1023.
// Retour :
//    uint8_t -> code entre 0 et 1023 proportionnel à la grandeur analogique d'entrée
//               Entrée CAN : 0 à 5V --> Sortie CAN : 0 à 1023
//-------------------------------------------------------------------------------------------------
uint16_t CaptAnalog::convertirEnCodeNumerique()
{
   static unsigned long millisDernConv = millis(); // mémorise instant de la dernière conversion
   unsigned long millisNow;   // contient nb de millisecondes écoulées à cet instant

   millisNow = millis(); // lit nb de millisecondes écoulées à cet instant
   if (millisNow - millisDernConv >= m_intervalConversion)
   {
      // durée depuis la dernière conversion écoulée, nouvelle conversion va être effectuée
      convertirEnCodeNumeriqueNow(); // code numérique proportionnel grandeur analogique d'entrée
      millisDernConv = millisNow;
      m_conversionEffectue = 1;
   }
   return m_codeCan;
}

//-------------------------------------------------------------------------------------------------
// Calcule en pourcentage la valeur de la tension de sortie du capteur par rapport à la pleine
// échelle. Le convertisseur analogique/numérique (CAN 10 bits) convertit la grandeur analogique 
// d'entrée, variant de 0 à 5V, en pourcentage soit de 0 à 100 %.
// Retour :
//    unsigned char -> pourcentage entre 0 et 100 proportionnel à la grandeur analogique d'entrée
//                      Entrée CAN : 0 à 5V --> Sortie CAN : 0 à 100 %
//-------------------------------------------------------------------------------------------------
uint8_t CaptAnalog::convertirEnPourcentage()
{
   static unsigned long millisDernConv = millis(); // mémorise instant de la dernière conversion
   unsigned long millisNow;   // contient nb de millisecondes écoulées à cet instant

   millisNow = millis(); // lit nb de millisecondes écoulées à cet instant
   if (millisNow - millisDernConv >= m_intervalConversion)
   {
      // durée depuis la dernière conversion écoulée, nouvelle conversion va être effectuée
      convertirEnCodeNumeriqueNow(); // code numérique proportionnel grandeur analogique d'entrée
      // map(value, fromLow, fromHigh, toLow, toHigh), change d'échelle : 0 à 1023 -> 0 à 100
      m_codeCanPourcent =(unsigned char) map((long) m_codeCan, 0, 1023, 0, 100); 
      millisDernConv = millisNow;
      m_conversionEffectue = 1;
   }
   return m_codeCanPourcent;
}

//-------------------------------------------------------------------------------------------------
// Debug : affiche le contenu des variables de l'objet
// Nécessite l'initialisation de la liaison série 0 dans le setup() :  Serial.begin(115200);
//-------------------------------------------------------------------------------------------------
void CaptAnalog::afficherVariableMembre()
{
   Serial.println("");
   Serial.println("");
   Serial.println("********** Variables membres objet CaptAnalog (potentiometre) ********");
   Serial.print("m_pinCaptAnalog : "); Serial.println(m_pinCaptAnalog);
   Serial.print("m_intervalConversion : "); Serial.println(m_intervalConversion);
   Serial.print("m_codeCan : "); Serial.println(m_codeCan);
   Serial.print("m_codeCanPourcent : "); Serial.println(m_codeCanPourcent);
   Serial.print("m_conversionEffectue : "); Serial.println(m_conversionEffectue);
   Serial.println("********** Fin variables membres objet CaptAnalog (potentiometre) ****");
   Serial.println("");
}
