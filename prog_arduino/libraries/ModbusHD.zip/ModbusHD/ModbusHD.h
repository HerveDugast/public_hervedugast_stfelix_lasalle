#pragma once
/*-------------------------------------------------------------------------------------------------
Classe : ModbusHD.h        Version : 3.0           Version arduino : 1.6.5
Auteur : H. Dugast         Date : 20-04-2016

Fonction résumée : Prépare, envoie, réceptionne et analyse des trames sur une liaison série 
                   utilisant le protocole modbus
Protocole modbus :
|Adresse|Commande|nb octets données| data ... (ou rien) | CRC16 poids faible | crc16 poids fort |
La longueur effective de la trame émise est calculée dans le programme
   -> LongTrame = nb octets données + 5
Remarque : cette bibliothèque n'est pas optimisée, par manque de temps
------------------------------------------------------------------------------------------------ */

#include <Arduino.h>

// Durée au bout de laquelle, si les erreurs n'ont pas disparu, un RAZ est effectué
const uint32_t DUREE_ATTENTE_RAZ = 3000; // durée (en ms) max en erreur avant RAZ

// PLAGE DES PARAMETRES pour la création d'objet
const uint8_t TAILLE_TRAME_MIN_RS = 5;	// longueur minimale trame Modbus
const uint8_t TAILLE_TRAME_MAX_RS = 40;	// longueur maximale trame Modbus (en théorie 255)
const uint8_t PORT_SERIE_NUM_MAX = 3; // nb max de port série sur la carte arduino utilisée
const uint8_t NB_MAX_CMD_MODBUS = 25;		// nb max de commandes modbus (en théorie 127)
// durée max autorisée (en ms) sans recevoir de trame
const uint32_t DUREE_SANS_TRAM_RX = 3000;	
const uint8_t Z_TEST_PIN_A = 7; // !!! test
const uint8_t Z_TEST_PIN_B = 8; // !!! test



// Accusé de réception
#define AR_NON_DEMANDE			0	// pas de réponse demandée après réception d'une trame
#define AR_DEMANDE				1	// réponse demandée après réception d'une trame
#define AR_ACQUIT				2	// réponse reçue et vérifiée
#define AR_ERREUR				9	// erreur dans la réponse reçue
#define AR_NB_DUREE_OCTET		12	// nb de durées octets pour recevoir un AR (accusé réception)

// Erreurs ... chaque erreur correspond à une puissance de 2 les erreurs s'additionnent
#define ERR_01_AR_T	 0x01	// pas de réponse malgré demande AR ou réponse erronée, gérée par émet
#define ERR_02_AR_R	 0x02	// pas de réponse malgré demande AR ou réponse erronée, gérée par récept
#define ERR_04_CRC			0x04	// code CRC16 erroné
#define ERR_08_CMD_NOK		0x08	// commande modbus non reconnue

#define ERR_10_OCTET_RX_UP		0x10	// trame reçue trop longue ou index Rx trop élevé
#define ERR_20_DUREE_RX_UP		0x20	// durée max réception trame écoulée et pas de fin de trame
#define ERR_40_DUREE_SANS_RX	0x40	// pas de réception trame pendant le temps défini
#define ERR_80_EMIS_EN_COURS	0x80	// demande émission mais émission précédente non terminée

// erreurs détail : pour connaitre l'emplacement précis qui a déclenché l'erreur
#define ERRD_0001_CRC_RX		0x0001	// **code CRC16 erroné
#define ERRD_0002_CRC_RX		0x0002	// **code CRC16 erroné
#define ERRD_0004_CRC_TX		0x0004	// **code CRC16 erroné

#define ERRD_0010_TX_ON			0x0010	// **erreur : émission en cours
#define ERRD_0020_TX_ON			0x0020	// **erreur : émission en cours
#define ERRD_0040_TX_ON			0x0040	// **erreur : émission en cours
#define ERRD_0080_OCTET_RX_UP	0x0080	// **erreur, trop d'octets reçus sur Rx (index tableau)

#define ERRD_0100_OCTET_RX_UP	0x0100	// **erreur, trop d'octets reçus sur Rx (index tableau)
#define ERRD_0200_OCTET_RX_UP	0x0200	// **erreur, trop d'octets reçus sur Rx (index tableau)
#define ERRD_0400_OCTET_DATA_UP	0x0400	// **erreur, 3ème octet (nb data) trop élevé 
#define ERRD_0800_OCTET_RX_UP	0x0800	// **erreur, trop d'octets reçus sur Rx (index tableau)

#define ERRD_1000_CMD_NOK		0x1000	// **erreur commande non reconnue
#define ERRD_2000_CMD_NOK		0x2000	// **erreur commande non reconnue
#define ERRD_4000_CMD_NOK		0x4000	// **erreur commande non reconnue

// erreur CODE
#define ERRC_0001_BAUD			0x0001	// **vitesse en bauds définie par utilisateur non reconnue
#define ERRC_0002_PORT_SERIE	0x0002	// **erreur dans le choix numéro de port série demandé
#define ERRC_0004_TAILLE_TRAME	0x0004	// **erreur longueur trame

#define ERRC_0010_NB_CMD		0x0010	// **erreur dans le nombre de commande modbus autorisées
#define ERRC_0040_INDEX_CMD		0x0040	// **erreur index tableau trop élevé
#define ERRC_0080_INDEX_CMD		0x0080	// **erreur index tableau trop élevé

#define ERRC_0100_INDEX_CMD		0x0100	// **erreur index tableau trop élevé
#define ERRC_0200_INDEX_TX		0x0200	// **erreur index tableau trop élevé
#define ERRC_0400_INDEX_TX		0x0400	// **erreur index tableau trop élevé
#define ERRC_0800_INDEX_TX		0x0800	// **erreur index tableau trop élevé

#define ERRC_1000_INDEX_TX		0x1000	// **erreur index tableau trop élevé
#define ERRC_2000_INDEX_TX		0x2000	// **erreur index tableau trop élevé
#define ERRC_4000_INDEX_TX		0x4000	// **erreur index tableau trop élevé
#define ERRC_8000_INDEX_TX		0x8000	// **erreur index tableau trop élevé

// Erreurs liées au code C++ (paramètres pour créer un objet en dehors de plage autorisée, 
//    index tableau trop élevé...)
// L'erreur ERR_CODE regroupe toutes les erreurs liées au code C++
// Erreurs possibles (cumulatives) :
// • Erreur m_baudrate -> si valeur ne se trouve pas dans table TAB_BAUD_T (ModbusHD.cpp)
//	 valeurs possibles : 115200, 57600, 38400, 28800, 19200, 14400, 9600, 4800, 2400, 1200, 600, 300
// • Erreur port série		-> plage autorisée : 0 à 3
// • Erreur longueur trame	-> plage autorisée : TAILLE_TRAME_MIN_RS à TAILLE_TRAME_MAX_RS
// • Erreur nb de commandes Modbus -> plage autorisée : 0 à NB_MAX_CMD_MODBUS
// • Erreur durée max entre 2 Rx   -> valeur interdite : 0
// • Erreur index tableau trop élevé (copie tableau, chargement tableau, ajout élément tableau)

class ModbusHD 
{
  public:
    enum STATUS {OK = 0, NOK = 1};

	// Constructeur, prépare un objet pour préparer, envoyer et réceptionner des trames sur 
   // liaison série avec le protocole modbus
 	ModbusHD();
	// Constructeur, prépare un objet pour préparer, envoyer et réceptionner des trames sur 
   // liaison série avec le protocole modbus
	ModbusHD(uint32_t vitBaud, uint8_t portSerieNum, uint8_t tailleTrameMax, uint8_t brochLedEmis,
      uint8_t brochLedRecep, uint8_t pinLedErreur, uint8_t nbCmdModbus,
      uint32_t dureeMaxSansTramRecep);

	//---------------------------------------------------------------------------------------------
	// Public : Fonctions liées à l'émission de trame
	//---------------------------------------------------------------------------------------------
	// émet la trame en fonction des octets stockés dans m_tabTx et des options choisies
	uint8_t trameEmettre(bool arDemande, bool modeAuto);				
	// crée la trame réponse en fonction de la trame reçue, détecte éventuelles erreurs
	uint8_t trameReponseDefautCreer();
	
	// Efface l'index, la taille et les éléments du tableau
	void tabTxEffacer();
	// calcule le code CRC16 de la table m_tabTx puis la compare aux valeurs stockées dans m_tabTx
	bool tabTxCrc16VerifierValidite();

	// copie le tableau (source) précisé par l'utilisateur dans la table m_tabTx de l'objet
	void setTabTxChargerValeurs(uint8_t* tabSource, uint8_t nbVal);
	// ajoute un élément au tableau m_tabTx à la position demandée (0 à ...)
	void setTabTxAjouter(uint8_t val, uint8_t index);
	// ajoute un élément au tableau m_tabTx juste après le dernier élément enregistré (m_tabTxIndex)
	void setTabTxAjouter(uint8_t);
	// calcule le code CRC16 de la table m_tabTx puis l'ajoute à la fin de m_tabTx
	void setTabTxCrc16CalculerEtAjouter();

	// copie la table m_tabTx de l'objet dans un tableau (destination) précisé par l'utilisateur
	void getTabTxRecupererValeurs(uint8_t* tabDest, uint8_t nbVal);
	// Retourne la taille du tableau
	uint8_t getTabTxTaille();
	// Retourne valeur de l'élément du tableau m_tabTx situé à la position index
	uint8_t getTabTxElemNum(uint8_t index);
	// Retourne valeur du code CRC16 bas (poids faible) de la table m_tabTx
	uint8_t getTabTxCrcLow();
	// Retourne valeur du code CRC16 haut (poids fort) de la table m_tabTx
	uint8_t getTabTxCrcHigh();


	//---------------------------------------------------------------------------------------------
	// Public : Fonctions liées à la réception de trame
	//---------------------------------------------------------------------------------------------
	// Réception de la trame (stocke les octets reçus dans la table de réception)
	// Dès qu'un octet est détecté dans le buffer de réception, ce sous-programme lit
	//	 toute la trame. La fin de trame est détectée lorsque le bus série est au repos 
	//	 pendant une durée correspondant à la transmission de 2 mots (ou à 2 ms mini).
	uint8_t trameRecevoir(bool modeAuto);
	// Efface l'index, la taille et les éléments du tableau
	void tabRxEffacer();
	// calcule le code CRC16 de la table m_tabRx puis la compare aux valeurs stockées dans m_tabRx
	bool tabRxCrc16VerifierValidite();

	// copie la table m_tabRx de l'objet dans un tableau (destination) précisé par l'utilisateur
	void getTabRxRecupererValeurs(uint8_t* tabDest, uint8_t nbVal);
	// Retourne valeur de l'élément du tableau m_tabRx situé à la position index
	uint8_t getTabRxElemNum(uint8_t index);
	// Retourne la taille du tableau
	uint8_t getTabRxTaille();
	// Retourne valeur signalant comment la fin de trame a été détectée
	uint8_t getRxFinTrame();
	// Retourne valeur du code CRC16 bas (poids faible) de la table m_tabRx
	uint8_t getTabRxCrcLow();
	// Retourne valeur du code CRC16 haut (poids fort) de la table m_tabRx
	uint8_t getTabRxCrcHigh();
	// ajoute un élément au tableau m_tabRx juste après le dernier élément enregistré (m_tabRxIndex)
	void setTabRxAjouter(uint8_t val);

	//---------------------------------------------------------------------------------------------
	// Public : Fonctions liées aux commandes Modbus
	//---------------------------------------------------------------------------------------------
	// Efface l'index, la taille et les éléments du tableau
	void tabCmdEffacer();
	// Affichage des variables dans un terminal série (debug) par le port COM (Tx0/Rx0)
	void afficherTabCmd();
	// vérifie que la commande reçue existe bien dans la table des commandes autorisées
	bool tabCmdVerifierCmdValide(uint8_t cmdRecu);

	// copie le tableau (source) précisé par l'utilisateur dans la table m_tabCmd de l'objet
	void setTabCmdChargerValeurs(uint8_t* tabSource, uint8_t nbVal);
	// ajoute un élément au tableau m_tabCmd juste après le dernier élément enregistré 
   // (m_tabTxIndex)
	void setTabCmd_ajouter(uint8_t);

	//copie la table m_tabCmd de l'objet dans un tableau (destination) précisé par l'utilisateur
	void getTabCmd_recuperer_valeurs(uint8_t* tabDest, uint8_t nbVal);


	//---------------------------------------------------------------------------------------------
	// Public : Fonctions autres
	//---------------------------------------------------------------------------------------------
	// Affichage des variables dans un terminal série (debug) par le port COM (Tx0/Rx0)
	void afficherVariableMembre();
	void afficherTabRx();
	void afficherTabTx();

	// Retourne valeur correspondant aux erreurs détectées
	uint8_t getErreur();
   	// calcule le code CRC16 de la table précisée puis l'ajoute à la fin de cette table
	void setTabCrc16CalculerEtAjouter(uint8_t* table);
  
  protected:
	// variables définies à la création de l'objet liaison série 
	uint32_t m_baudrate;				// vitesse de transmission en m_baudrate
	uint32_t m_dureeOctet;		// durée d'un bit de la trame (dépend de m_baudrate)
	uint32_t m_dureeAttenteTx;	// durée attente entre 2 trames à émettre (dépend de m_baudrate)
	uint32_t m_dureeAttenteRx;	// durée attente pour détecter fin trame (dépend de m_baudrate)
	uint8_t m_portSerieNumF;	// numéro du port série à utiliser
	uint8_t m_tailleTrameMaxF;	// longueur max trame (en octets), valeur identique pour Rx et Tx
	uint32_t m_dureeMaxRecep;	// durée max d'une réception (évite blocage)
   uint8_t m_pinLedEmis;	// numéro broche LED pour signaler émission 
   uint8_t m_pinLedRecep;	// numéro broche LED pour signaler réception
   uint8_t m_pinLedErreur;	// numéro broche LED pour signaler erreur
   uint32_t m_dureeMaxSansTramRx; // durée attente max entre 2 réceptions
	uint8_t m_nbMaxCmdModbus;	// taille max du tableau des commandes (nb max de commandes)

	// variables liées à l'émission de trame
	uint8_t m_tabTx[TAILLE_TRAME_MAX_RS];	// Table d'émission
	uint8_t m_tabTxTaille;     // taille tableau m_tabTx
	uint8_t m_tabTxIndex;       // index du tableau m_tabTx
	uint32_t m_txDureeEmis; // durée nécessaire pour émettre trame
	uint32_t m_txMicros;		// mémorise instant début envoi trame (en µs)
	bool m_txEnCours;				// 1 -> trame en cours d'émission   0 -> pas d'émission en cours
	uint8_t m_txArEtat;		// état de l'accusé de réception (0, 1 ou 2)

	// variables liées à la réception de trame
	uint8_t m_tabRx[TAILLE_TRAME_MAX_RS];	// Table de réception
	uint8_t m_tabRxTaille;      // taille tableau m_tabRx
	uint8_t m_tabRxIndex;       // index du tableau m_tabRx
	uint32_t m_rxMicros;	// mémorise instant début réception trame (en µs)
	uint32_t m_rxMicrosDern;	// mémorise instant dernier octet reçu (en µs)
	bool m_rxEnCours;	// signale qu'une trame a été reçue
	// m_rxFinTrame signale comment la fin de trame a été détectée
	// 		0 -> fin trame pas encore détectée
	//		1 -> fin trame détectée par nb octets attendus bien reçus
	//		2 -> fin trame détectée par ligne Rx au repos depuis 2 durées émission octet
	//		3 -> fin trame détectée par durée réception longueur trame max écoulée
	uint8_t m_rxFinTrame;
	uint8_t m_rxArEtat;		// état de l'accusé de réception (0, 1 ou 2)

	// variables liées au tableau de commandes Modbus autorisées
	uint8_t m_tabCmd[NB_MAX_CMD_MODBUS]; // Table de commandes Modbus autorisées
	uint8_t m_tabCmdTaille;	// taille tableau m_tabCmd
	uint8_t m_tabCmdIndex;		 // index du tableau m_tabCmd

	// variables autres
	uint8_t m_erreur;	// gestion des erreurs (ModbusHD et création objet)
	uint32_t m_erreurDetail;	// permet de localiser rapidement l'emplacement dans le programme 
								// qui a déclenché l'erreur
	uint32_t m_erreurCode;	// gestion des erreurs de code 

	//---------------------------------------------------------------------------------------------
	// Protégé : Fonctions liées à l'émission de trame
	//---------------------------------------------------------------------------------------------
	// gère l'émission et erreurs éventuelles, vérifie si émission en cours 
	bool zTrameTxGerer(uint32_t instantDepart);
	// émet les octets de la table d'émission (m_tabTx) sur la liaison série
	// gère LED, mémorise instant envoi...
	void zTabTxEmettre();
	// allume LED émission
	void zLedTxAllumer();
	// éteint LED émission
	void zLedTxEteindre();

   // allume LED erreur
   void zLedErreurAllumer();
   // éteint LED erreur
   void zLedErreurEteindre();

   void z_test_A__mettre_a_1();
   void z_test_A__mettre_a_0();
   void z_test_A__basculer();
   void z_test_B__mettre_a_1();
   void z_test_B__mettre_a_0();
   void z_test_B__basculer();
   
	//---------------------------------------------------------------------------------------------
	// Protégé : Fonctions liées à la réception de trame
	//---------------------------------------------------------------------------------------------
	// détecte fin de trame sur ligne Rx, gère erreur
	uint8_t zTrameRxGerer(uint32_t instantDepart, uint32_t instantDernOctet);
	// détecte absence de trame sur ligne Rx pendant la durée max précisé (m_dureeMaxSansTramRx)
	void zTrameRxDetecterAbsence(uint32_t instantDepart);
	// LED, Détecte les erreurs dans la table de réception (CRC, longueur trame, commande inconnue)
	void zTrameRxErreurGerer();
	// Réceptionne données reçues par ligne Rx (lecture buffer réception)
	// gère LED, instant début...
	void zTabRxReceptionnerOctet();
	// allume LED réception
	void zLedRxAllumer();
	// éteint LED réception
	void zLedRxEteindre();


	//---------------------------------------------------------------------------------------------
	// Protégé : Fonctions autres
	//---------------------------------------------------------------------------------------------
	// attend jusqu'à l'instant demandé : durée attente (en µs) = instantDepart + dureeMicrosec
	void zAttendreMicrosec(uint32_t instantDepart, unsigned dureeMicrosec);
	// gestion accusé de réception !!!!! à écrire !!!!!
	void z_ar_gerer(uint8_t nbOctetRecu);
	// signale les erreurs de la liaison série en allumant LED émission
	void zErreurSignaler();
	// calcule le code CRC16 de la table d'émission (m_tabTx) ou de réception (m_tabRx)
	void zTabCrc16Calculer(uint8_t* table, uint8_t* crcHigh, uint8_t* crcLow);
};

// END OF FILE