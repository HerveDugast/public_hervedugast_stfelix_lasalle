#pragma once
/*-------------------------------------------------------------------------------------------------
Classe : ModbusHD.cpp      Version : 3.0           Version arduino : 1.6.5
Auteur : H. Dugast         Date : 20-04-2016

Fonction résumée : Prépare, envoie, réceptionne et analyse des trames sur une liaison série 
                   utilisant le protocole modbus
Protocole modbus :
|Adresse|Commande|nb octets données| data ... (ou rien) | CRC16 poids faible | crc16 poids fort |
La longueur effective de la trame émise est calculée dans le programme
   -> LongTrame = nb octets données + 5
Remarque : cette bibliothèque n'est pas optimisée, par manque de temps
------------------------------------------------------------------------------------------------ */
#include <ModbusHD.h>
#include <avr/pgmspace.h>

// déclaration d'une structure pour mémoriser les caractéristiques de la liaison série 
typedef struct TAB_BAUD_T
{
  uint32_t m_baudrate;
  uint32_t durOctet;
  uint32_t durAttentTx;
  uint32_t durAttentRx;
};

// Tableau contenant les valeurs de vitesse en bauds autorisées
static const TAB_BAUD_T TABLE_BAUD[] PROGMEM = 
{
 // • m_baudrate : vitesse laison ModbusHD
 // • durOctet (en µs) : durée d'un octet (1 start + 8 data + 1 stop)
 // • durAttentTx (en µs) : durée d'attente entre 2 trames successives
 //		En théorie, il faut attendre 3,5 fois le temps de transmission d'un mot
 //		car destinataire considère fin message au bout de 2 fois temps transmission mot
 //		Dans cette classe, temps attente entre 2 émissions successives (sans demande AR) : 
 //			durAttentTx = 3,5 x durée octet (en µs)
 // • durAttentRx (en µs) : durée d'attente pour détecter fin de trame (avec demande AR)
 //		Cette durée sert à détecter le plus rapidement possible la fin de trame pour
 //		que le récepteur puisse répondre rapidement
 //		Dans cette classe, temps attente avant traitement trame reçue :
 //			durAttentRx = 2 x durée octet (en µs)
 //	m_baudrate  ,	durOctet ,	durAttentTx,	durAttentRx
  { 115200,		87,			304,			174		},
  { 57600,		174,		608,			348		},
  { 38400,		261,		912,			521		},
  { 31250,		320,		1120,			640		},
  { 28800,		348,		1216,			695		},
  { 19200,		521,		1823,			1042	},
  { 14400,		695,		2431,			1389	},
  { 9600,		1042,		3646,			2084	},
  { 4800,		2084,		7292,			4167	},
  { 2400,		4167,		14584,			8334	},
  { 1200,		8334,		29167,			16667	},
  { 600,		16667,		58334,			33334	},
  { 300,		33334,		116667,			66667	}
};

/* Tableau valeur CRC16 octet poids fort */
static const uint8_t T_CRC_HAUT[] PROGMEM = {
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01,
0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40
} ;

/* Tableau valeur CRC16 octet poids faible */
static const char T_CRC_BAS[] PROGMEM = {
0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4,
0x04, 0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD,
0x1D, 0x1C, 0xDC, 0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7,
0x37, 0xF5, 0x35, 0x34, 0xF4, 0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE,
0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2,
0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 0x78, 0xB8, 0xB9, 0x79, 0xBB,
0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 0x50, 0x90, 0x91,
0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 0x88,
0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80,
0x40
};

// ------------------------------------------------------------------------------------------------
// Public : Constructeur, prépare un objet pour préparer, envoyer et réceptionner des trames sur 
// liaison série avec le protocole modbus
// ------------------------------------------------------------------------------------------------
ModbusHD::ModbusHD()
{
	m_baudrate = 9600;			// vitesse de transmission en m_baudrate
	m_dureeOctet = 1042;		// durée d'un bit de la trame (dépend de m_baudrate)
	m_dureeAttenteTx = 5000;	// durée attente entre 2 trames à émettre (dépend de m_baudrate)
	m_dureeAttenteRx = 2084;	// durée attente pour détecter fin trame (dépend de m_baudrate)
	m_portSerieNumF = 0;		// numéro du port série à utiliser
	// longueur max trame (en octet), valeur identique pour Rx et Tx
   m_tailleTrameMaxF = TAILLE_TRAME_MAX_RS;	
	m_dureeMaxRecep = m_tailleTrameMaxF * m_dureeOctet; // durée max d'une réception (évite blocage)
	m_pinLedEmis = 99;	// 99 -> pas de LED pour signaler émission 
	m_pinLedRecep = 99;	// 99 -> pas de LED pour signaler réception
	m_pinLedErreur = 99;	// 99 -> pas de LED pour signaler erreur
	// durée attente max entre 2 réceptions en µs
	m_dureeMaxSansTramRx = DUREE_SANS_TRAM_RX * 1000; 
	m_txDureeEmis = 0;
	m_txMicros = micros();
	m_txEnCours = 0;
	m_txArEtat = 0;
	m_rxMicros = micros();
	m_rxMicrosDern = micros();
	m_rxEnCours = 0;
	m_rxFinTrame = 0;
	m_rxArEtat = 0;
   m_erreur = 0;		// signale les éventuelles erreurs
	m_erreurCode = 0;
	m_erreurDetail = 0;
	tabTxEffacer();
	tabRxEffacer();
	tabCmdEffacer();
}

// ------------------------------------------------------------------------------------------------
// Public : Constructeur avec surcharge
// Paramètres :
//		• baudrate -> valeurs autorisées : valeurs présentes dans table TAB_BAUD_T
//			            vitesse liaison série en bauds	  					   
//		• portSerieNum -> valeurs autorisées : 0, 1, 2 ou 3, numéro du port série utilisé       
//		• tailleTrameMax -> valeurs autorisées : TAILLE_TRAME_MIN_RS à TAILLE_TRAME_MAX_RS
//			                  longueur max (en octets) trame Tx et trame Rx
//		• pinLedEmis -> valeurs autorisées :	n° broche sortie numérique arduino
//			                  numéro broche de commande LED émission		99 : pas de LED
//		• pinLedRecep -> valeurs autorisées :	n° broche sortie numérique arduino
//			                  numéro broche de commande LED réception		99 : pas de LED
//		• pinLedErreur -> valeurs autorisées :	n° broche sortie numérique arduino
//			                  numéro broche de commande LED erreur		99 : pas de LED
//		• nbMaxCommandModbus -> valeurs autorisées :	1 à NB_MAX_CMD_MODBUS
//			                        nombre total de commandes Modbus (cmd stockées dans m_tabCmd)
//		• dureeMaxSansTramRecep -> valeurs autorisées : toutes valeurs
//			                           durée max autorisée (en ms) sans recevoir de trame 
//                				0 -> pas de durée max		> 0 -> durée max prise en compte (en ms)
// ------------------------------------------------------------------------------------------------
ModbusHD::ModbusHD(uint32_t baudrate, uint8_t portSerieNum, uint8_t tailleTrameMax,
   uint8_t pinLedEmis, uint8_t pinLedRecep, uint8_t pinLedErreur, uint8_t nbMaxCommandModbus,
	uint32_t dureeMaxSansTramRecep)
{
	uint32_t nb;

	// vérifie si la vitesse en bauds définie par l'utilisateur est valide (présent dans TABLE_BAUD)
	// si OK, définit les variables m_baudrate, m_dureeOctet, m_dureeAttenteTx et m_dureeAttenteRx
	// PROBLEME AVEC : i < sizeof(TABLE_BAUD)
	for (uint8_t i = 0 ; i < 13 ; i++)
	{
		if (pgm_read_dword(&TABLE_BAUD[i].m_baudrate) == baudrate)
		{
			m_baudrate = baudrate;
			m_dureeOctet = pgm_read_dword(&TABLE_BAUD[i].durOctet);
			m_dureeAttenteTx = pgm_read_dword(&TABLE_BAUD[i].durAttentTx);
			m_dureeAttenteRx = pgm_read_dword(&TABLE_BAUD[i].durAttentRx);
		}
	}
	
	// Définit vitesse transmission en bauds par défaut en cas d'erreur
	// m_baudrate = 0 -> valeur proposée par utilisateur non trouvée dans le tableau
	if (m_baudrate == 0)
	{
      // vitesse en bauds définie par utilisateur non reconnue
      m_erreurCode = m_erreurCode | ERRC_0001_BAUD;	
		m_baudrate = 9600;	// valeur par défaut
		m_dureeOctet = 1042;	// durée en µs d'un octet à 9600 bauds
		m_dureeAttenteTx = 3646;	// durée en ms nécessaire entre 2 trames à envoyer
		m_dureeAttenteRx = 2084;	// durée en ms nécessaire pour détecter fin de trame
	}

	// Définit port série utilisé et éventuelle erreur "PORT"
	if (portSerieNum <= PORT_SERIE_NUM_MAX)
		m_portSerieNumF = portSerieNum;
	else if (portSerieNum > PORT_SERIE_NUM_MAX)
	{
      // erreur dans choix numéro de port série demandé
      m_erreurCode = m_erreurCode  | ERRC_0002_PORT_SERIE; 
		m_portSerieNumF = 0;	// port série par défaut
	}

   if (portSerieNum == 0)
      Serial.begin(m_baudrate);
   else if (portSerieNum == 1)
   {
#if defined(UBRR1H)  // vérifie que le port série 1 existe bien
      Serial1.begin(m_baudrate);
#endif 
   }
   else if (portSerieNum == 2)
   {
#if defined(UBRR2H)  // vérifie que le port série 1 existe bien
      Serial2.begin(m_baudrate);
#endif 
   }
   else if (portSerieNum == 3)
   {
#if defined(UBRR3H)  // vérifie que le port série 1 existe bien
      Serial3.begin(m_baudrate);
#endif 
   }

	// Définit longueur trame et éventuelle erreur "TRAM"
	if (tailleTrameMax >= TAILLE_TRAME_MIN_RS && tailleTrameMax <= TAILLE_TRAME_MAX_RS)
		m_tailleTrameMaxF = tailleTrameMax;
	else
	{
		m_erreurCode = m_erreurCode | ERRC_0004_TAILLE_TRAME;	// erreur longueur trame
		m_tailleTrameMaxF = TAILLE_TRAME_MAX_RS;
	}
	// calcule durée max de la réception en µs pour éviter blocage
	m_dureeMaxRecep = m_tailleTrameMaxF * m_dureeOctet;	

	// Définit la sortie LED pour signaler les envois et réceptions
	// pinLedEmis >= 99 -> pas de sortie LED
	m_pinLedEmis = pinLedEmis;
	if (m_pinLedEmis < 99)
	{
		pinMode(m_pinLedEmis, OUTPUT);
		zLedTxEteindre();
	}
	m_pinLedRecep = pinLedRecep;
	if (m_pinLedRecep < 99)
	{
		pinMode(m_pinLedRecep, OUTPUT);
		zLedRxEteindre();
	}
   m_pinLedErreur = pinLedErreur;
   if (m_pinLedErreur < 99)
   {
      pinMode(m_pinLedErreur, OUTPUT);
      zLedRxEteindre();
   }
   
   // définit nb de commandes Modbus autorisées
	if (nbMaxCommandModbus > 0  && nbMaxCommandModbus < NB_MAX_CMD_MODBUS)
		m_nbMaxCmdModbus = nbMaxCommandModbus;
	else
	{
		m_erreurCode = m_erreurCode | ERRC_0010_NB_CMD;	// erreur dans le nb de commandes
		m_nbMaxCmdModbus = NB_MAX_CMD_MODBUS;
	}

	// définit durée max (en ms) autorisées entre 2 réceptions
	// 0 -> pas de durée max		> 0 -> durée max prise en compte (en ms)
	m_dureeMaxSansTramRx = dureeMaxSansTramRecep * 1000; // (m_dureeMaxSansTramRx en µs)
	m_txDureeEmis = 0;
	m_txMicros = micros();
	m_txEnCours = 0;
	m_txArEtat = 0;
	m_rxMicros = micros();
	m_rxMicrosDern = micros();
	m_rxEnCours = 0;
	m_rxFinTrame = 0;
	m_rxArEtat = 0;
   m_erreur = 0;		// signale les éventuelles erreurs
	m_erreurCode = 0;
	m_erreurDetail = 0;
	tabTxEffacer();
	tabRxEffacer();
	tabCmdEffacer();
}

// ------------------------------------------------------------------------------------------------
// Public : émet les octets de la table d'émission (m_tabTx) sur la liaison série 
//	uniquement si le port série choisi est disponible
// Paramètres :
//		arDemande : 0 -> pas de demande d'AR (accusé de réception),	donc n'attend pas de réponse	
//					   1 -> demande AR (accusé de réception), donc attend une réponse (maître)			
//		modeAuto :	0 -> pas de mode auto, aucune attente en cas d'émission en cours
//					   1 -> mode automatique, attend éventuell. fin émission en cours avant d'émettre
// Retour :
//		uint8_t -> valeur des éventuelles erreurs  (voir début fichier ModbusHD.h pour liste erreurs)
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::trameEmettre(bool arDemande, bool modeAuto)
{
	// vérifie si émission de trame en cours (port série occupé)
	//	m_txEnCours = 0 -> pas d'émission en cours
	//  m_txEnCours = 1 -> émission en cours
	zTrameTxGerer(m_txMicros);
   //////// RAZ erreur  !!!!! ajout patch cause dysfonctionnement non trouvé !!!!!
   //////m_erreur = 0;
   //////m_erreurCode = 0;
   //////m_erreurDetail = 0;
   //////zLedErreurEteindre();
   //////// Fin RAZ erreur  !!!!! ajout patch cause dysfonctionnement non trouvé !!!!!

	// 1er cas : arDemande = 0 et modeAuto = 0 : pas d'AR et pas de mode auto
	//	• Si émission de trame en cours -> retourne 0 : erreur "BUSY"
	//	• Si pas de trame en cours d'émission, émet octets table émission et retourne code erreur
	if (arDemande == 0	&&	modeAuto == 0)
	{
		if (m_txEnCours)	// émission trame en cours
			m_erreurDetail = m_erreurDetail | ERRD_0010_TX_ON; // erreur : émission en cours
		else
		{
			m_erreurDetail = m_erreurDetail & ~ERRD_0010_TX_ON; // enlève erreur : émission en cours
			zTabTxEmettre();
			m_txArEtat = AR_NON_DEMANDE;
		}
	}
	
	// 2ème cas : arDemande = 0 et modeAuto = 1 : pas d'AR et mode automatique
	//	• Si émission de trame en cours 
	//	-> attente : fin émission trame (m_txDureeEmis) + délai min entre 2 trames (m_dureeAttenteTx)
	//	• émet octets table émission
	//	• retourne code erreur
	else if (arDemande == 0	&&	modeAuto == 1)
	{
		zAttendreMicrosec(m_txMicros, m_txDureeEmis + m_dureeAttenteTx);
		m_txEnCours = 0;	// pas de trame 
		zTabTxEmettre();
		m_txArEtat = AR_NON_DEMANDE;
	}

	// 3ème cas : arDemande = 1 et modeAuto = 0 : AR demandé et pas de mode auto
	//	• Si émission de trame en cours -> retourne 0 : erreur "BUSY"
	//	• Si pas de trame en cours d'émission, émet octets table émission et retourne code erreur
	else if (arDemande == 1	&&	modeAuto == 0)
	{
		if (m_txEnCours)	// émission trame en cours
			m_erreurDetail = m_erreurDetail | ERRD_0020_TX_ON; // erreur : émission en cours
		else
		{
			m_erreurDetail = m_erreurDetail & ~ERRD_0020_TX_ON; // enlève erreur : émission en cours
			zTabTxEmettre();
			m_txArEtat = AR_DEMANDE;
		}
	}
	
	// 4ème cas : arDemande = 1 et modeAuto = 1 : AR demandé et mode automatique
	//	• Si émission de trame en cours 
	//		-> attente : fin émission trame précédente (m_txDureeEmis)
	//	• émet octets table émission
	//	• attente : fin émission trame courante (m_txDureeEmis + m_dureeAttenteRx)
	//	• lecture buffer de réception Rx pendant TAILLE_TRAME_MIN_RS * (m_dureeOctet + 2) mini
	//	• vérification validité trame réponse
	//	• retourne code erreur
	else if (arDemande == 1	&&	modeAuto == 1) 
	{
		if (m_txEnCours)	// émission trame en cours
			m_erreurDetail = m_erreurDetail | ERRD_0040_TX_ON; // erreur : émission en cours
		else
		{
			m_erreurDetail = m_erreurDetail & ~ERRD_0040_TX_ON; // enlève erreur : émission en cours
			zTabTxEmettre();
			m_txArEtat = AR_DEMANDE;
		}
	}
	zErreurSignaler();
	return m_erreur;
}

// ------------------------------------------------------------------------------------------------
//	Public : Elaboration trame réponse par défaut :
//		trame sans erreur : | adresse |     cmd    | nb data (=0) | CRC16L | CRC16H |
//		trame avec erreur : | adresse | cmd + 0x80 | nb data (=1) | code erreur | CRC16L | CRC16H |
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::trameReponseDefautCreer()
{
	m_tabTx[0] = m_tabRx[0];
	// vérification validité message reçu
	if (tabRxCrc16VerifierValidite() == NOK)	// si code CRC de la trame réceptionnée est erroné
	{
		m_erreurDetail = m_erreurDetail | ERRD_0002_CRC_RX;		// signale erreur
      m_erreur = m_erreur | ERR_04_CRC;
	}
	else
	{
		m_erreurDetail = m_erreurDetail & ~ERRD_0002_CRC_RX;		// enlève erreur
      m_erreur = m_erreur & ~ERR_04_CRC;
	}
	if (tabCmdVerifierCmdValide(m_tabRx[1]) == NOK)	// si commande reçue ne se trouve pas dans m_tabCmd
	{
		m_erreurDetail = m_erreurDetail | ERRD_1000_CMD_NOK;		// signale erreur
      m_erreur = m_erreur | ERR_08_CMD_NOK;
	}
	else
	{
		m_erreurDetail = m_erreurDetail & ~ERRD_1000_CMD_NOK;		// enlève erreur
      m_erreur = m_erreur & ~ERR_08_CMD_NOK;
	}

	// modifie 2ème octet si erreur
	if (m_erreur == 0)
	{
		m_tabTx[1] = m_tabRx[1];			// recopie commande reçue
		m_tabTx[2] = 0;					// nb data
	}
	else 
	{
		m_tabTx[1] = m_tabRx[1] + 0x80;		// signale erreur en ajoutant 0x80 à commande reçue
		m_tabTx[2] = 1;					// nb data
		m_tabTx[3] = m_erreur;				// erreur
	}
	setTabTxCrc16CalculerEtAjouter();				// calcul et ajout code CRC trame réponse
	m_rxFinTrame = 0;			// utile plus tard pour renseigner sur la fin de trame
	return m_erreur;
}

// ------------------------------------------------------------------------------------------------
//	Public : Efface l'index, la taille et les éléments du tableau TabTx (table d'émission)
// ------------------------------------------------------------------------------------------------
void ModbusHD::tabTxEffacer()
{ 
	m_tabTxTaille = 0;
	m_tabTxIndex = 0;
    for (uint8_t i = 0 ; i < m_tailleTrameMaxF ; i++)
		m_tabTx[i] = 0;
}

// ------------------------------------------------------------------------------------------------
//	Public : Affichage de la table d'émission dans un terminal série
//	Affichage par le port COM (Tx0/Rx0), également utilisé par la programmation de la carte arduino
// ------------------------------------------------------------------------------------------------
void ModbusHD::afficherTabTx()
{
   Serial.println("--- Table emission : TabTx -------------------------------------------");
	// longueur trame à afficher ne tient pas compte de la cohérence du 3ème octet (nb data) !!!
	for (uint8_t i = 0 ; i < m_tabTxTaille ; i++)
	{
		Serial.print(m_tabTx[i], HEX);
		Serial.print(" ");
	}
	Serial.println(" ");
   Serial.println("--- Fin table emission : TabTx ---------------------------------------");
}

// ------------------------------------------------------------------------------------------------
// Public : calcule le code CRC16 de la table m_tabTx puis la compare aux valeurs stockées dans
// m_tabTx. La longueur de la trame est déterminée à partir de m_tabTx[2] (nb data).
// On en déduit le nb d'octets à prendre en compte dans le calcul 
// Retour :
//		bool -> OK = 0 : code CRC valide
//				NOK = 1 : code CRC non valide
// ------------------------------------------------------------------------------------------------
bool ModbusHD::tabTxCrc16VerifierValidite()
{
	bool valRetour;
	uint8_t crcL, crcH;

	zTabCrc16Calculer(m_tabTx, &crcL, &crcH);
	if (  (m_tabTx[m_tabTxTaille - 2] == crcL) && (m_tabTx[m_tabTxTaille - 1] == crcH)  )
		valRetour = OK;
	else 
		valRetour = NOK;
	return valRetour;
}

// ------------------------------------------------------------------------------------------------
// Public : copie le tableau (source) précisé par l'utilisateur dans la table m_tabTx de l'objet
// Paramètres :
//		tabSource : pointeur d'octet (tableau source)
//		nbVal : nb de valeurs à copier du tableau source
// ------------------------------------------------------------------------------------------------
void ModbusHD::setTabTxChargerValeurs(uint8_t* tabSource, uint8_t nbVal)
{
	// vérifie erreur index tableau et signale erreur éventuelle
	if (nbVal > sizeof(m_tabTx))
	{
		m_erreurCode = m_erreurCode | ERRC_1000_INDEX_TX;	// signale erreur index tableau trop élevé
		nbVal = sizeof(m_tabTx);			// fixe valeur nbVal au maximum possible
	}
	// copie le tableau source dans table m_tabTx
	for (uint8_t i = 0 ; i < nbVal ; i++) 	m_tabTx[i] = tabSource[i];
	m_tabTxTaille = TAILLE_TRAME_MIN_RS + m_tabTx[2];
	m_tabTxIndex = m_tabTxTaille;
}

// ------------------------------------------------------------------------------------------------
// Public : ajoute un élément au tableau m_tabTx à la position demandée (0 à ...)
// Paramètres :
//		val			-> valeur à ajouter dans la table m_tabTx
//		index	-> index (emplacement) de la valeur à ajouter dans la table m_tabTx
// ------------------------------------------------------------------------------------------------
void ModbusHD::setTabTxAjouter(uint8_t val, uint8_t index)
{
	if (index > m_tailleTrameMaxF)		// si débordement index tableau
	{
		index = m_tailleTrameMaxF - 1; // nouvelle valeur écrase dernier octet !!!
		m_erreurCode = m_erreurCode | ERRC_2000_INDEX_TX;	// signale erreur
	}
	m_tabTx[index] = val;
	if (m_tabTxIndex < index)
		m_tabTxIndex = index; // met l'index sur le dernier élément du tableau
	m_tabTxTaille = m_tabTxIndex;
}

// ------------------------------------------------------------------------------------------------
// Public : ajoute un élément au tableau m_tabTx juste après le dernier élément enregistré
// (m_tabTxIndex) 
// Paramètres :
//		val	-> valeur à ajouter dans la table m_tabTx à la dernière position
// ------------------------------------------------------------------------------------------------
void ModbusHD::setTabTxAjouter(uint8_t val)
{
	if (m_tabTxIndex >= m_tailleTrameMaxF)	// si tableau plein
	{
		m_tabTxIndex--;					// reste sur dernier élément, dernier octet sera écrasé !!!
		m_erreurCode = m_erreurCode | ERRC_4000_INDEX_TX;	// signale erreur
	}
	m_tabTx[m_tabTxIndex++] = val;
	m_tabTxTaille = m_tabTxIndex;
}

// ------------------------------------------------------------------------------------------------
// Public : calcule le code CRC16 de la table m_tabTx puis l'ajoute à la fin de m_tabTx
// ------------------------------------------------------------------------------------------------
void ModbusHD::setTabTxCrc16CalculerEtAjouter()
{
	uint8_t crcL, crcH;

	zTabCrc16Calculer(m_tabTx, &crcL, &crcH);
	m_tabTx[TAILLE_TRAME_MIN_RS - 2 + m_tabTx[2]] = crcL;
	m_tabTx[TAILLE_TRAME_MIN_RS - 1 + m_tabTx[2]] = crcH;
	m_tabTxTaille = TAILLE_TRAME_MIN_RS + m_tabTx[2];
	m_tabTxIndex = m_tabTxTaille;
}

// ------------------------------------------------------------------------------------------------
// Public : calcule le code CRC16 de la table précisée puis l'ajoute à la fin de cette table
// ------------------------------------------------------------------------------------------------
void ModbusHD::setTabCrc16CalculerEtAjouter(uint8_t* table)
{
	uint8_t crcL, crcH;

	zTabCrc16Calculer(table, &crcL, &crcH);
	table[TAILLE_TRAME_MIN_RS - 2 + table[2]] = crcL;
	table[TAILLE_TRAME_MIN_RS - 1 + table[2]] = crcH;
}

// ------------------------------------------------------------------------------------------------
//	Public : copie la table m_tabTx de l'objet dans un tableau (destination) précisé par 
// l'utilisateur 
// Paramètres :
//		tabDest : pointeur d'octet (tableau de destination)
//		nbVal : nb de valeurs à copier dans le tableau de destination
// ------------------------------------------------------------------------------------------------
void ModbusHD::getTabTxRecupererValeurs(uint8_t* tabDest, uint8_t nbVal)
{
	// vérifie erreur index tableau et signale erreur éventuelle
	if (nbVal > sizeof(m_tabTx))
	{
		m_erreurCode = m_erreurCode | ERRC_8000_INDEX_TX;	// signale erreur index tableau trop élevé
		nbVal = sizeof(m_tabTx);			// fixe valeur nbVal au maximum possible
	}
	// copie le tableau m_tabTx dans table
	for (uint8_t i = 0 ; i < nbVal ; i++) 	tabDest[i] = m_tabTx[i];
}

// ------------------------------------------------------------------------------------------------
// Public : Retourne la taille du tableau
// Retour :
//		uint8_t -> taille du tableau en octet
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::getTabTxTaille()
{
	return m_tabTxTaille;
}

// ------------------------------------------------------------------------------------------------
// Public : Retourne valeur de l'élément du tableau m_tabTx situé à la position index
// Paramètre :
//		index -> position de l'élément à retourner
// Retour :
//		uint8_t -> valeur de l'élément situé à la position index
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::getTabTxElemNum(uint8_t index)
{
	if (index > m_tailleTrameMaxF)
	{
		m_erreurCode = m_erreurCode | ERRC_0800_INDEX_TX;	// erreur "IDX", index trop élevé
		index = m_tailleTrameMaxF - 1; // pointe le dernier élément du tableau
	}
	return m_tabTx[index];		// retourne l'élément du tableau demandé
}

// ------------------------------------------------------------------------------------------------
// Public : Retourne valeur du code CRC16 bas (poids faible) de la table m_tabTx
// Retour :
//		uint8_t -> code CRC16 poids faible
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::getTabTxCrcLow()
{
	return m_tabTx[m_tabTxTaille - 1];
}

// ------------------------------------------------------------------------------------------------
// Public : Retourne valeur du code CRC16 haut (poids fort) de la table m_tabTx
// Retour :
//		uint8_t -> code CRC16 poids fort
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::getTabTxCrcHigh()
{
	return m_tabTx[m_tabTxTaille - 2];
}

// ------------------------------------------------------------------------------------------------
// Public : Réceptionne les octets reçus par la liaison série
// Paramètres :
//		modeAuto :	0 -> pas de mode auto, aucune attente, réceptionne les octets reçus à la volée
//					1 -> mode automatique, dès le premier octet reçu, réceptionne les suivants
//						 et attend la fin de la réception
// Retour :
//		m_rxFinTrame : 0 -> fin trame pas encore détectée
//					 1 -> fin trame détectée par nb octets attendus bien reçus
//					 2 -> fin trame détectée par ligne Rx au repos depuis 2 durées émission octet
//					 3 -> fin trame détectée par durée réception longueur trame max écoulée
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::trameRecevoir(bool modeAuto)
{
	// vérifie si émission de trame en cours (port série occupé)
	// et permet de remettre m_txEnCours à 0
	//	m_txEnCours = 0 -> pas d'émission en cours
	//  m_txEnCours = 1 -> émission en cours
	zTrameTxGerer(m_txMicros);

	// 1er cas : modeAuto = 0 : pas de mode auto, pas d'attente
	//	• réceptionne données reçues par Rx (lecture buffer réception)
	//	• vérifie si fin de trame
	//	• si fin de trame, vérifie validité trame (longueur, commande, CRC)
	//	• retourne code résultat (état ou erreurs éventuelles) :
	if (m_txEnCours == 0)
	{
      if (modeAuto == 0)
		{
         zTabRxReceptionnerOctet();
			zTrameRxGerer(m_rxMicros, m_rxMicrosDern);
			// fin de trame détectée, vérification des erreurs
			if (m_rxFinTrame > 0)
				zTrameRxErreurGerer();

			//détecte absence trame sur ligne Rx pendant la durée max précisée (m_dureeMaxSansTramRx)
			if (m_dureeMaxSansTramRx != 0)
				zTrameRxDetecterAbsence(m_rxMicros);
		}
		// 2è cas : modeAuto = 1 : mode automatique, dès le premier octet reçu, réceptionne les
      // suivants et attend la fin de la réception
		//	• réceptionne données reçues par Rx (lecture buffer réception)
		//	• vérifie si fin de trame
		//	• si fin de trame, vérifie validité trame (longueur, commande, CRC)
		//	• retourne code résultat (état ou erreurs éventuelles) :
		else
		{
			do
			{
				zTabRxReceptionnerOctet();
				zTrameRxGerer(m_rxMicros, m_rxMicrosDern);
				// fin de trame détectée, vérification des erreurs
				if (m_rxFinTrame > 0)
					zTrameRxErreurGerer();

				// détecte absence de trame sur ligne Rx pendant la durée max précisée 
            // (m_dureeMaxSansTramRx)
				if (m_dureeMaxSansTramRx != 0)
					zTrameRxDetecterAbsence(m_rxMicros);
			} while (m_rxEnCours == 1);
		}
	}

	zErreurSignaler();
	return m_rxFinTrame;
}

// ------------------------------------------------------------------------------------------------
//	Public : Efface l'index, la taille et les éléments du tableau TabRx (table de réception)
// ------------------------------------------------------------------------------------------------
void ModbusHD::tabRxEffacer()
{ 
	m_tabRxTaille = 0;
	m_tabRxIndex = 0;
    for (uint8_t i = 0 ; i < m_tailleTrameMaxF ; i++)
		m_tabRx[i] = 0;
	m_rxFinTrame = 0;
}

// ------------------------------------------------------------------------------------------------
//	Public : Affichage de la table de réception dans un terminal série
//	Affichage par le port COM (Tx0/Rx0), également utilisé par la programmation de la carte arduino
// ------------------------------------------------------------------------------------------------
void ModbusHD::afficherTabRx()
{
   Serial.println("--- Table reception : TabRx ------------------------------------------");
	// longueur trame à afficher ne tient pas compte de la cohérence du 3ème octet (nb data) !!!
	for (uint8_t i = 0 ; i < m_tabRxTaille ; i++)
	{
		Serial.print(m_tabRx[i], HEX);
		Serial.print(" ");
	}
	Serial.println(" ");
   Serial.println("--- Fin table reception : TabRx --------------------------------------");
}

// ------------------------------------------------------------------------------------------------
// Public : calcule le code CRC16 de la table m_tabRx puis la compare aux valeurs stockées dans
// m_tabRx. La longueur de la trame est déterminée à partir de m_tabRx[2] (nb data)
// On en déduit le nb d'octets à prendre en compte dans le calcul 
// Retour :
//		bool ->  OK = 0 : code CRC valide
//				   NOK = 1 : code CRC non valide
// ------------------------------------------------------------------------------------------------
bool ModbusHD::tabRxCrc16VerifierValidite()
{
	bool valRetour;
	uint8_t crcL, crcH;

	zTabCrc16Calculer(m_tabRx, &crcL, &crcH);
	if (  (m_tabRx[m_tabRxTaille - 2] == crcL) && (m_tabRx[m_tabRxTaille - 1] == crcH)  )
		valRetour = OK;
	else 
		valRetour = NOK;
	return valRetour;
}

// ------------------------------------------------------------------------------------------------
//	Public : copie la table m_tabRx de l'objet dans un tableau (destination) précisé par 
// l'utilisateur 
// Paramètres :
//		tabDest : pointeur d'octet (tableau de destination)
//		nbVal : nb de valeurs à copier dans le tableau de destination
// ------------------------------------------------------------------------------------------------
void ModbusHD::getTabRxRecupererValeurs(uint8_t* tabDest, uint8_t nbVal)
{
	// vérifie erreur index tableau et signale erreur éventuelle
	if (nbVal > sizeof(m_tabRx))
	{
		m_erreurCode = m_erreurCode | ERRC_0400_INDEX_TX;	// signale erreur index tableau trop élevé
		nbVal = sizeof(m_tabRx);			// fixe valeur nbVal au maximum possible
	}
	// copie le tableau m_tabTx dans table
	for (uint8_t i = 0 ; i < nbVal ; i++) 	tabDest[i] = m_tabRx[i];
}

// ------------------------------------------------------------------------------------------------
// Public : Retourne valeur de l'élément du tableau m_tabRx situé à la position index
// Paramètre :
//		index -> position de l'élément à retourner
// Retour :
//		uint8_t -> valeur de l'élément situé à la position index
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::getTabRxElemNum(uint8_t index)
{
	if (index > m_tailleTrameMaxF)
	{
		m_erreurCode = m_erreurCode | ERRC_0200_INDEX_TX;	// erreur "IDX", index trop élevé
		index = m_tailleTrameMaxF - 1; // pointe le dernier élément du tableau
	}
	return m_tabRx[index];		// retourne l'élément du tableau demandé
}

// ------------------------------------------------------------------------------------------------
// Public : Retourne la taille du tableau
// Retour :
//		uint8_t -> taille du tableau en octet
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::getTabRxTaille()
{
	return m_tabRxTaille;
}

// ------------------------------------------------------------------------------------------------
// Public : Retourne valeur signalant comment la fin de trame a été détectée
// Retour :
//		uint8_t -> méthode qui a détecté fin de trame
//					 		0 : fin trame pas encore détectée
//							1 : nb octets attendus bien reçus
//							2 : ligne Rx au repos depuis 2 durées émission octet
//							3 : durée réception longueur trame max écoulée
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::getRxFinTrame()
{
	return m_rxFinTrame;
}

// ------------------------------------------------------------------------------------------------
// Public : Retourne valeur du code CRC16 bas (poids faible) de la table m_tabRx
// Retour :
//		uint8_t -> code CRC16 poids faible
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::getTabRxCrcLow()
{
	return m_tabRx[TAILLE_TRAME_MIN_RS - 2 + m_tabRx[2]];
}

// ------------------------------------------------------------------------------------------------
// Public : Retourne valeur du code CRC16 haut (poids fort) de la table m_tabRx
// Retour :
//		uint8_t -> code CRC16 poids fort
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::getTabRxCrcHigh()
{
	
	return m_tabRx[TAILLE_TRAME_MIN_RS - 1 + m_tabRx[2]];
}

// ------------------------------------------------------------------------------------------------
// Public : ajoute un élément au tableau m_tabRx juste après le dernier élément enregistré 
// (m_tabRxIndex) 
// Paramètres :
//		val	-> valeur à ajouter dans la table tabRTx à la dernière position
// ------------------------------------------------------------------------------------------------
void ModbusHD::setTabRxAjouter(uint8_t val)
{
	if (m_tabRxIndex >= m_tailleTrameMaxF)	// si tableau plein
	{
		m_tabRxIndex--;					// reste sur dernier élément, dernier octet sera écrasé !!!
		// erreur, trop d'octets reçus sur Rx (index tableau)
		m_erreurDetail = m_erreurDetail | ERRD_0100_OCTET_RX_UP; 
	}
	else
		m_erreurDetail = m_erreurDetail & ~ERRD_0100_OCTET_RX_UP;	// enlève erreur
	m_tabRx[m_tabRxIndex++] = val;
	m_tabRxTaille = m_tabRxIndex;
}


// ------------------------------------------------------------------------------------------------
//	Public : Efface l'index, la taille et les éléments du tableau TabCmd (table des commandes)
// ------------------------------------------------------------------------------------------------
void ModbusHD::tabCmdEffacer()
{ 
	m_tabCmdTaille = 0;
	m_tabCmdIndex = 0;
    for (uint8_t i = 0 ; i < m_nbMaxCmdModbus ; i++)
		m_tabCmd[i] = 0;
}

// ------------------------------------------------------------------------------------------------
//	Public : Affichage de la table des commandes dans un terminal série
//	Affichage par le port COM (Tx0/Rx0), également utilisé par la programmation de la carte arduino
// ------------------------------------------------------------------------------------------------
void ModbusHD::afficherTabCmd()
{
   Serial.println("--- TabCmd -----------------------------------------------------------");
	for (uint8_t i = 0 ; i < m_tabCmdTaille ; i++)
	{
		Serial.print(m_tabCmd[i], HEX);
		Serial.print(" ");
	}
	Serial.println(" ");
   Serial.println("--- Fin TabCmd -------------------------------------------------------");
}

// ------------------------------------------------------------------------------------------------
// Public : vérifie que la commande reçue existe bien dans la table des commandes autorisées
// Retour :
//		bool ->  OK = 0 : commande reconnue
//				   NOK = 1: commande non reconnue
// ------------------------------------------------------------------------------------------------
bool ModbusHD::tabCmdVerifierCmdValide(uint8_t cmdRecu)
{
	bool valRetour = NOK;

	for (uint8_t i = 0 ; i < m_tabCmdTaille ; i++)
	{
		if (cmdRecu == m_tabCmd[i])
		{
			valRetour = OK;			// commande reconnue
			break;
		}
	}
	return valRetour;
}

// ------------------------------------------------------------------------------------------------
// Public : copie le tableau (source) précisé par l'utilisateur dans la table m_tabCmd de l'objet
// Paramètres :
//		tabSource : pointeur d'octet (tableau source)
//		nbVal : nb de valeurs à copier du tableau source
// ------------------------------------------------------------------------------------------------
void ModbusHD::setTabCmdChargerValeurs(uint8_t* tabSource, uint8_t nbVal)
{
	// vérifie erreur index tableau et signale erreur éventuelle
	if (nbVal > sizeof(m_tabCmd))
	{
		m_erreurCode = m_erreurCode | ERRC_0100_INDEX_CMD;	// signale erreur index tableau trop élevé
		nbVal = sizeof(m_tabCmd);			// fixe valeur nbVal au maximum possible
	}
	// copie le tableau source dans table m_tabTx
	for (uint8_t i = 0 ; i < nbVal ; i++) 	m_tabCmd[i] = tabSource[i];
}

// ------------------------------------------------------------------------------------------------
//	Public : ajoute un élément au tableau m_tabCmd juste après le dernier élément enregistré 
// (m_tabTxIndex)
// ------------------------------------------------------------------------------------------------
void ModbusHD::setTabCmd_ajouter(uint8_t val)
{
	if (m_tabCmdIndex >= m_nbMaxCmdModbus)	// si tableau plein
	{
		m_tabCmdIndex--;					// reste sur dernier élément, dernier octet sera écrasé !!!
		m_erreurCode = m_erreurCode | ERRC_0080_INDEX_CMD;	// signale erreur
	}
	m_tabCmd[m_tabCmdIndex++] = val;
	m_tabCmdTaille = m_tabCmdIndex;
}

// ------------------------------------------------------------------------------------------------
//	Public : copie la table m_tabCmd de l'objet dans un tableau (destination) précisé par
// l'utilisateur 
// Paramètres :
//		tabDest : pointeur d'octet (tableau de destination)
//		nbVal : nb de valeurs à copier dans le tableau de destination
// ------------------------------------------------------------------------------------------------
void ModbusHD::getTabCmd_recuperer_valeurs(uint8_t* tabDest, uint8_t nbVal)
{
	// vérifie erreur index tableau et signale erreur éventuelle
	if (nbVal > sizeof(m_tabCmd))
	{
		m_erreurCode = m_erreurCode | ERRC_0040_INDEX_CMD;	// signale erreur index tableau trop élevé
		nbVal = sizeof(m_tabCmd);			// fixe valeur nbVal au maximum possible
	}
	// copie le tableau m_tabTx dans table
	for (uint8_t i = 0 ; i < nbVal ; i++) 	tabDest[i] = m_tabCmd[i];
}

// ------------------------------------------------------------------------------------------------
//	Public : Affichage de toutes les variables de l'objet dans un terminal série (debug)
//	Affichage par le port COM (Tx0/Rx0), également utilisé par la programmation de la carte arduino
// ------------------------------------------------------------------------------------------------
void ModbusHD::afficherVariableMembre()
{
	Serial.println("");
   Serial.println("********** Variables membres objet ModbusHD **************************");
	Serial.print("m_baudrate = "); 	Serial.println(m_baudrate);
	Serial.print("m_dureeOctet = "); 	Serial.println(m_dureeOctet);
	Serial.print("m_dureeAttenteTx = "); 	Serial.println(m_dureeAttenteTx);
	Serial.print("m_dureeAttenteRx = "); 	Serial.println(m_dureeAttenteRx);
	Serial.print("m_portSerieNumF = "); 	Serial.println(m_portSerieNumF);
	Serial.print("m_tailleTrameMaxF = "); Serial.println(m_tailleTrameMaxF);
	Serial.print("m_dureeMaxRecep = "); Serial.println(m_dureeMaxRecep);
	Serial.print("m_pinLedEmis = "); Serial.println(m_pinLedEmis);
	Serial.print("m_pinLedRecep = "); Serial.println(m_pinLedRecep);
	Serial.print("m_dureeMaxSansTramRx = "); Serial.println(m_dureeMaxSansTramRx);
	Serial.print("m_nbMaxCmdModbus = "); Serial.println(m_nbMaxCmdModbus);
	Serial.println("");

   Serial.println("------------- Emission -----------------------------------------------");
	afficherTabTx();
	Serial.print("m_tabTxTaille = "); Serial.println(m_tabTxTaille);
	Serial.print("m_tabTxIndex = "); Serial.println(m_tabTxIndex);
	Serial.print("m_txDureeEmis = "); Serial.println(m_txDureeEmis);
	Serial.print("m_txMicros = "); Serial.println(m_txMicros);
	Serial.print("m_txEnCours = "); Serial.println(m_txEnCours);
	Serial.print("m_txArEtat = "); Serial.println(m_txArEtat);
	Serial.println("");

   Serial.println("------------- Reception ----------------------------------------------");
	afficherTabRx();
	Serial.print("m_tabRxTaille = "); Serial.println(m_tabRxTaille);
	Serial.print("m_tabRxIndex = "); Serial.println(m_tabRxIndex);
	Serial.print("m_rxMicros = "); Serial.println(m_rxMicros);
	Serial.print("m_rxMicrosDern = "); Serial.println(m_rxMicrosDern);
	Serial.print("m_rxEnCours = "); Serial.println(m_rxEnCours);
	Serial.print("m_rxFinTrame = "); Serial.println(m_rxFinTrame);
	Serial.print("m_rxArEtat = "); Serial.println(m_rxArEtat);
	Serial.println("");

   Serial.println("------------- Commande -----------------------------------------------");
	afficherTabCmd();
	Serial.print("m_tabCmdTaille = "); Serial.println(m_tabCmdTaille);
	Serial.print("m_tabCmdIndex = "); Serial.println(m_tabCmdIndex);
	Serial.println("");

   Serial.println("------------- ERREURS ------------------------------------------------");
	Serial.print("m_erreur = "); Serial.print(m_erreur, HEX); Serial.println(" H");
	Serial.print("m_erreurDetail = "); Serial.print(m_erreurDetail, HEX); Serial.println(" H");
	Serial.print("m_erreurCode = "); Serial.print(m_erreurCode, HEX); Serial.println(" H"); 
   Serial.println("********** Fin variables membres objet ModbusHD **********************");
   Serial.println("");
}

// ------------------------------------------------------------------------------------------------
// Public : Retourne valeur correspondant aux erreurs détectées
//			   Chaque erreur correspond à une puissance de 2, les erreurs s'additionnent
// Retour :
//		uint8_t -> valeur des éventuelles erreurs  (voir début fichier ModbusHD.h pour liste erreurs)
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::getErreur()
{
	return m_erreur;
}

// ------------------------------------------------------------------------------------------------
// Protégée :  - Vérifie si une émission est en cours en calculant la durée écoulée entre 
//				      l'instant présent et l'instant de début de début d'envoi de trame
//			      - Détecte les erreurs d'AR (accusé de réception) 
// Paramètres :
//		instantDepart : instant en µs du début de l'envoi de la trame
// ------------------------------------------------------------------------------------------------
bool ModbusHD::zTrameTxGerer(uint32_t instantDepart)
{
	uint32_t microsOn, dureeEcoulee;

	// calcule durée écoulée depuis début envoi trame
	microsOn = micros(); // instant courant en µs
	if (microsOn > instantDepart)
			dureeEcoulee = microsOn - instantDepart;
		else	// débordement (toutes les 70 mn)
			dureeEcoulee = 4294967295 - instantDepart + microsOn;
	// Vérification AR bien reçu et signale éventuellement erreur
	if (  (m_txArEtat == AR_DEMANDE)  
				&&  (dureeEcoulee > m_txDureeEmis + m_dureeOctet * AR_NB_DUREE_OCTET)  )
	{
      // pas de réponse reçue dans les délais, gérée par transmission
      m_erreur = m_erreur | ERR_01_AR_T;	
		m_txArEtat = AR_ERREUR;
	}
	else if (m_txArEtat == AR_ACQUIT || m_txArEtat == AR_NON_DEMANDE)
      m_erreur = m_erreur & ~ERR_01_AR_T;
	// vérifie si une trame est en cours d'émission
	if (dureeEcoulee > m_txDureeEmis)
		m_txEnCours = 0;	// fin émission détectée

	return m_txEnCours;
}

// ------------------------------------------------------------------------------------------------
// Protégée : émet les octets de la table d'émission (m_tabTx) sur la liaison série 
//	- allume/éteint LED émission pour signaler émission
//		(LED reste allumée le temps d'envoyer la commande d'envoi au module RS232)
//	- mémorise instant début émission en µs (m_txMicros)
// - vérifie le code CRC avant d'émettre et calcule la durée d'émission nécessaire en µs
// - envoie au module RS232 la trame à émettre (l'émission réelle dure plus longtemps)
// ------------------------------------------------------------------------------------------------
void ModbusHD::zTabTxEmettre()
{
	bool crcOk;
	uint8_t valRetour;

	zLedTxAllumer();		// allume LED émission
	m_txEnCours = 1;			// signale début émission sur port série
	m_txMicros = micros();	// mémorise instant debut émission en µs
	m_txDureeEmis = (uint32_t) m_tabTxTaille * m_dureeOctet;	// calcule durée émission en µs
	
	// vérifie validité code CRC table émission
	if (tabTxCrc16VerifierValidite() == OK)
		m_erreurDetail = m_erreurDetail & ~ERRD_0004_CRC_TX;	// enlève éventuelle erreur CRC
	else
		m_erreurDetail = m_erreurDetail | ERRD_0004_CRC_TX;		// signale erreur CRC

	// signale une erreur si la commande est >= 0x80
	if (m_tabTx[1] < 0x80)
      // enlève éventuelle erreur commande non reconnue
		m_erreurDetail = m_erreurDetail & ~ERRD_2000_CMD_NOK; 
	else
		m_erreurDetail = m_erreurDetail | ERRD_2000_CMD_NOK;	// signale erreur commande non reconnue

	// émet octets de la table d'émission
	for (uint8_t i = 0 ; i < m_tabTxTaille ; i++)
	{
		switch (m_portSerieNumF)
		{
			case 0:
				Serial.write(m_tabTx[i]);
				break;
			
			#if defined(UBRR1H)
			case 1:
				Serial1.write(m_tabTx[i]);
				break;
			#endif		

			#if defined(UBRR2H)
			case 2:
				Serial2.write(m_tabTx[i]);
				break;
			#endif
			
			#if defined(UBRR3H)
			case 3:
				Serial3.write(m_tabTx[i]);
				break;
			#endif
		}
	}

	zLedTxEteindre();
	tabRxEffacer();
}

// ------------------------------------------------------------------------------------------------
// Protégée : allume LED émission
// ------------------------------------------------------------------------------------------------
void ModbusHD::zLedTxAllumer()
{
	if (m_pinLedEmis < 99)	digitalWrite(m_pinLedEmis, 1);
}

// ------------------------------------------------------------------------------------------------
// Protégée : éteint LED émission
// ------------------------------------------------------------------------------------------------
void ModbusHD::zLedTxEteindre()
{
	if (m_pinLedEmis < 99)	digitalWrite(m_pinLedEmis, 0);
}

// ------------------------------------------------------------------------------------------------
// Protégée : détecte fin de trame sur ligne Rx, gère erreur
// Paramètres :
//		instantDepart : instant (en µs) du début de l'envoi de la trame
//		instantDernOctet : instant (en µs) du dernier octet réceptionné
// ------------------------------------------------------------------------------------------------
uint8_t ModbusHD::zTrameRxGerer(uint32_t instantDepart, uint32_t instantDernOctet)
{
	uint32_t microsOn, dureeEcouleeDepart, dureeEcouleeDern;
	// détection fin de trame
	// 1er cas : nb octets reçus = nb octets attendus
	//	vérifie longueur trame avec 3ème octet
	if (m_rxEnCours  &&  m_tabRxIndex >= TAILLE_TRAME_MIN_RS)
	{
		if (m_tabRx[2] > m_tailleTrameMaxF - TAILLE_TRAME_MIN_RS)
			// erreur, 3ème octet (nb data) trop élevé
			m_erreurDetail = m_erreurDetail | ERRD_0400_OCTET_DATA_UP;	
		else if (m_tabRxIndex == TAILLE_TRAME_MIN_RS + m_tabRx[2])
		{
			m_rxEnCours = 0;	// fin de trame détectée
			// enlève trop d'octets reçus sur Rx (index tableau)
			m_erreurDetail = m_erreurDetail & ~ERRD_0100_OCTET_RX_UP;	
			// enlève trop d'octets reçus sur Rx (index tableau)
			m_erreurDetail = m_erreurDetail & ~ERRD_0200_OCTET_RX_UP;	
			// enlève 3ème octet (nb data) trop élevé
			m_erreurDetail = m_erreurDetail & ~ERRD_0400_OCTET_DATA_UP;	
			m_rxFinTrame = 1;	// fin de trame détecté avec nb octets attendus bien reçus
		}
		else if (m_tabRxIndex > TAILLE_TRAME_MIN_RS + m_tabRx[2])
		{
			m_rxEnCours = 0;	// fin de trame détectée
			m_erreurDetail = m_erreurDetail | ERRD_0200_OCTET_RX_UP;	// longueur trame incorrecte
			m_rxFinTrame = 1;	// fin de trame détecté avec nb octets attendus bien reçus
		}
	}

	// détection fin de trame
	// 2ème cas : buffer réception vide et durée attente Rx écoulée
	//			 (ligne au repos pendant une durée correspondant à l'émission de 2 octets)

	// calcule durée écoulée depuis réception dernier octet
	if (m_rxEnCours)		// fin trame pas encore détectée
	{
		microsOn = micros(); // instant courant en µs
		if (microsOn > instantDernOctet)
			dureeEcouleeDern = microsOn - instantDernOctet;
		else	// débordement (toutes les 70 mn)
			dureeEcouleeDern = 4294967295 - instantDernOctet + microsOn;

		if (dureeEcouleeDern > m_dureeAttenteRx)
		{
			m_rxEnCours = 0;	// fin de trame détectée
			m_rxFinTrame = 2;	// détection par ligne Rx au repos depuis 2 durées émission octet
         m_erreur = m_erreur & ~ERR_20_DUREE_RX_UP;	// fin trame correcte
		}
	}

	// détection fin de trame
	// 3ème cas : temps réception trame de longueur max écoulé
	//		 	  (évite de bloquer le programme en réception)

	// calcule durée écoulée depuis début réception trame
	if (m_rxEnCours)		// fin trame pas encore détectée
	{
		// calcule durée écoulée depuis début réception trame
		microsOn = micros(); // instant courant en µs
		if (microsOn > instantDepart)
			dureeEcouleeDepart = microsOn - instantDepart;
		else	// débordement (toutes les 70 mn)
			dureeEcouleeDepart = 4294967295 - instantDepart + microsOn;

		if (dureeEcouleeDepart > m_dureeMaxRecep)
		{
			m_rxEnCours = 0;	// fin de trame détectée
			m_rxFinTrame = 3;	// détection par durée réception trame de longueur max écoulée
         m_erreur = m_erreur | ERR_20_DUREE_RX_UP;
		}
	}
	return m_rxFinTrame;
}

// ------------------------------------------------------------------------------------------------
// Protégée : détecte absence de trame sur ligne Rx pendant la durée max précisée 
// (m_dureeMaxSansTramRx)
// Paramètres :
//		instantDepart : instant (en µs) du début de l'envoi de la trame
// ------------------------------------------------------------------------------------------------
void ModbusHD::zTrameRxDetecterAbsence(uint32_t instantDepart)
{
	uint32_t microsOn, dureeEcouleeDepart, dureeEcouleeDern;
	microsOn = micros(); // instant courant en µs
	if (microsOn > instantDepart)
		dureeEcouleeDepart = microsOn - instantDepart;
	else	// débordement (toutes les 70 mn)
		dureeEcouleeDepart = 4294967295 - instantDepart + microsOn;
	// effectue RAZ sur la ligne Rx si une durée trop élevée s'est écoulée depuis dernière
   // réception SAUF si m_dureeMaxSansTramRx est nul 
   // (durée avant de réceptionner une trame non limitée)
	if (dureeEcouleeDepart > m_dureeMaxSansTramRx)
	{
      m_erreur = m_erreur | ERR_40_DUREE_SANS_RX;
		tabRxEffacer();
		m_rxMicros = micros();	// mémorise instant début réception trame (en µs)
	}
}

// ------------------------------------------------------------------------------------------------
// Protégée : - Eteint LED réception
// - Détecte les erreurs dans la table de réception (CRC, longueur trame, commande inconnue)
// ------------------------------------------------------------------------------------------------
void ModbusHD::zTrameRxErreurGerer()
{
	zLedRxEteindre();
	// détection erreur longueur trame
	if (m_tabRxIndex == TAILLE_TRAME_MIN_RS + m_tabRx[2])
		m_erreurDetail = m_erreurDetail & ~ERRD_0800_OCTET_RX_UP;	// longueur trame correcte
	else
		m_erreurDetail = m_erreurDetail | ERRD_0800_OCTET_RX_UP;	// longueur trame incorrecte

	// détection erreur CRC
	if (tabRxCrc16VerifierValidite() == OK)
		m_erreurDetail = m_erreurDetail & ~ERRD_0001_CRC_RX;		// enlève éventuelle erreur CRC
	else
		m_erreurDetail = m_erreurDetail | ERRD_0001_CRC_RX;		// signale erreur CRC

	// détection erreur commande inconnue
	bool cmdOK = 0;
	for (uint8_t i = 0 ; i < m_nbMaxCmdModbus ; i++)
	{
		if (m_tabRx[1] == m_tabCmd[i])
		{
			cmdOK = 1;
         // enlève erreur commande non reconnue
			m_erreurDetail = m_erreurDetail & ~ERRD_4000_CMD_NOK;	
			break;
		}
	}
	if (cmdOK == 0)
			m_erreurDetail = m_erreurDetail | ERRD_4000_CMD_NOK;	// erreur : commande non reconnue

	// détection erreur AR (accusé de réception)

	// Vérification AR bien reçu et signale éventuellement erreur
	if (m_txArEtat == AR_DEMANDE)
	{
		if (m_erreur == 0)
		{
			m_txArEtat = AR_ACQUIT;
         m_erreur = m_erreur & ~ERR_02_AR_R;	// enlève éventuelle erreur AR
		}
		else
		{
         m_erreur = m_erreur | ERR_02_AR_R;	// pas de réponse reçue dans les délais
			m_txArEtat = AR_ERREUR;
		}
	}
	else if (m_txArEtat == AR_ACQUIT || m_txArEtat == AR_NON_DEMANDE)
      m_erreur = m_erreur & ~ERR_02_AR_R;
}

// ------------------------------------------------------------------------------------------------
// Protégée : Réceptionne données reçues par ligne Rx (lecture buffer réception)
// • Si premier octet reçu :	
//		- allume LED réception 
//			(LED sera éteinte lorsque la fin de trame sera détectée, autre fonction)
//		- mémorise instant début réception en µs (m_rxMicros)
// • Mémorise instant du dernier octet reçu (microRxDern)
// • Stocke dans table de réception (m_tabRx) les octets reçus
// ------------------------------------------------------------------------------------------------
void ModbusHD::zTabRxReceptionnerOctet()
{
	bool crcOk;
	uint8_t valRetour, nbOctALire;
	uint32_t microsOn, microsOn2;
	bool trameDetect = 0;	// détecte début et fin trame
	uint8_t nbOctetRecu = 0;

// détection octets reçus sur ligne Rx
	switch (m_portSerieNumF)
	{
		case 0:
			nbOctALire = Serial.available();
			break;
			
		#if defined(UBRR1H)
		case 1:
			nbOctALire = Serial1.available();
			break;
		#endif		

		#if defined(UBRR2H)
		case 2:
			nbOctALire = Serial2.available();
			break;
		#endif
			
		#if defined(UBRR3H)
		case 3:
			nbOctALire = Serial3.available();
			break;
		#endif
	}
	// Données reçus par la liaison Rx disponibles (trame détectée)
	if (nbOctALire > 0)
	{
		// enlève erreur pas de réception trame pendant le temps défini
		m_erreurDetail = m_erreurDetail & ~ERR_40_DUREE_SANS_RX; 
		// Si premier octet à réceptionner, prépare et signale le début de la réception
		if (m_rxEnCours == 0)		// premier octet de la trame
		{
			tabRxEffacer();
			zLedRxAllumer();		// allume LED réception
			m_rxEnCours = 1;			// signale début réception sur port série
			m_rxMicros = micros();	// mémorise instant début réception trame (en µs)
			m_rxFinTrame = 0;			// utile plus tard pour renseigner sur la fin de trame
		}
		
		// vérifie que le nombre d'octets reçus est dans la plage autorisée
		if (nbOctALire + m_tabRxIndex <= TAILLE_TRAME_MAX_RS)
			m_erreurDetail = m_erreurDetail & ~ERRD_0080_OCTET_RX_UP;
		else
			m_erreurDetail = m_erreurDetail | ERRD_0080_OCTET_RX_UP;

// mémorise les octets reçus dans la table de réception
		switch (m_portSerieNumF)
		{
			case 0:
				m_rxMicrosDern = micros(); // mémorise instant dernier octet reçu (en µs)
				for (uint8_t i = 0 ; i < nbOctALire ; i++)
					setTabRxAjouter((uint8_t) Serial.read());
				break;
			
			#if defined(UBRR1H)
			case 1:
				m_rxMicrosDern = micros(); // mémorise instant dernier octet reçu (en µs)
				for (uint8_t i = 0 ; i < nbOctALire ; i++)
					setTabRxAjouter((uint8_t) Serial1.read());
				break;
			#endif		

			#if defined(UBRR2H)
			case 2:
				m_rxMicrosDern = micros(); // mémorise instant dernier octet reçu (en µs)
				for (uint8_t i = 0 ; i < nbOctALire ; i++)
					setTabRxAjouter((uint8_t) Serial2.read());
				break;
			#endif
			
			#if defined(UBRR3H)
			case 3:
				m_rxMicrosDern = micros(); // mémorise instant dernier octet reçu (en µs)
				for (uint8_t i = 0 ; i < nbOctALire ; i++)
					setTabRxAjouter((uint8_t) Serial3.read());
				break;
			#endif
		}
	}
}

// ------------------------------------------------------------------------------------------------
// Protégée : allume LED réception
// ------------------------------------------------------------------------------------------------
void ModbusHD::zLedRxAllumer()
{
	if (m_pinLedRecep < 99)	digitalWrite(m_pinLedRecep, 1);
}

// ------------------------------------------------------------------------------------------------
// Protégée : éteint LED réception
// ------------------------------------------------------------------------------------------------
void ModbusHD::zLedRxEteindre()
{
	if (m_pinLedRecep < 99)	digitalWrite(m_pinLedRecep, 0);
}

// ------------------------------------------------------------------------------------------------
// Protégée : allume LED erreur
// ------------------------------------------------------------------------------------------------
void ModbusHD::zLedErreurAllumer()
{
   if (m_pinLedErreur < 99)	digitalWrite(m_pinLedErreur, 1);
}

// ------------------------------------------------------------------------------------------------
// Protégée : éteint LED erreur
// ------------------------------------------------------------------------------------------------
void ModbusHD::zLedErreurEteindre()
{
   if (m_pinLedErreur < 99)	digitalWrite(m_pinLedErreur, 0);
}

// ------------------------------------------------------------------------------------------------
// Protégée : attend jusqu'à l'instant demandé : 
//		durée attente (en µs) = instantDepart + dureeMicrosec
// Paramètres :
//		instantDepart : instant (en µs) du début de l'envoi de la trame
//		microsec : nombre de microsecondes à attendre depuis l'instant de départ 
// ------------------------------------------------------------------------------------------------
void ModbusHD::zAttendreMicrosec(uint32_t instantDepart, unsigned dureeMicrosec)
{
	uint32_t microsOn, dureeEcoulee;

	do
	{
		microsOn = micros(); // instant courant en µs
		if (microsOn > instantDepart)
			dureeEcoulee = microsOn - instantDepart;
		else	// débordement (toutes les 70 mn)
			dureeEcoulee = 4294967295 - instantDepart + microsOn;
	} while (dureeEcoulee <= dureeMicrosec);
}

// ------------------------------------------------------------------------------------------------
// Protégée : signale les erreurs de la liaison série en allumant LED émission
// ------------------------------------------------------------------------------------------------
void ModbusHD::zErreurSignaler()
{
	uint8_t valRetour;
	// utile pour effacer les erreurs au bout d'un certain temps
	static uint32_t timeOnErr, timeOnErrPrec = 0; // nb de ms écoulées depuis mise sous tension
	if (m_erreurDetail > 0)
	{
		if (m_erreurDetail & 0x000F == 0)
         m_erreur = m_erreur & ~ERR_04_CRC;
		else
         m_erreur = m_erreur | ERR_04_CRC;

		if (m_erreurDetail & 0x0070 == 0)
         m_erreur = m_erreur & ~ERR_80_EMIS_EN_COURS;
		else
         m_erreur = m_erreur | ERR_80_EMIS_EN_COURS;

		if (m_erreurDetail & 0x0F80 == 0)
         m_erreur = m_erreur & ~ERR_10_OCTET_RX_UP;
		else
         m_erreur = m_erreur | ERR_10_OCTET_RX_UP;

		if (m_erreurDetail & 0xF000 == 0)
         m_erreur = m_erreur & ~ERR_08_CMD_NOK;
		else
         m_erreur = m_erreur | ERR_08_CMD_NOK;
	}

   if (m_erreur > 0 || m_erreurCode > 0)
      zLedErreurAllumer();
	else
		zLedErreurEteindre();

	// Permet d'effacer les erreurs au bout d'un certain temps (nécessaire dans certains cas)
	// -------------------------------------------------------------------------------------
	timeOnErr = millis();
	// gère le débordement de timeOn (au bout de 50 jours), timeOn max = 4 294 967 295
	if (timeOnErr < timeOnErrPrec)
		timeOnErrPrec = 0;
	
	if (m_erreur == 0)
		timeOnErrPrec = timeOnErr;

	// efface les erreurs en cours (sauf erreurs code)
	if (timeOnErr - timeOnErrPrec > DUREE_ATTENTE_RAZ)
	{
		zLedErreurEteindre();
		tabRxEffacer();
		m_rxMicros = micros();	// mémorise instant début réception trame (en µs)
      m_erreur = 0;
		m_erreurDetail = 0;
	}
}

// ------------------------------------------------------------------------------------------------
// Protégé : calcule le code CRC16 de la table indiquée en paramètre (m_tabTx ou m_tabRx)
// La longueur de la trame est déterminée à partir du 3ème octet tab...[2] (nb data)
// Format trame : Adresse | commande | nb data | (0 à nb data octets) | CRC16 Haut | CRC16 bas
// On en déduit le nb d'octets à prendre en compte dans le calcul 
// ------------------------------------------------------------------------------------------------
void ModbusHD::zTabCrc16Calculer(uint8_t* pTable, uint8_t* crcBas, uint8_t* crcHaut)
{
	uint8_t nbOctPourCalcul;	// nb d'octets à prendre en compte pour le calcul

	// détermine le nombre d'octets intervenant dans le calcul
	nbOctPourCalcul = 3 + pTable[2] ;

	unsigned int index ; /* will index into CRC lookup table */
	*crcHaut = 0xFF ;  // initialisation du code CRC octet haut (poids fort)
	*crcBas = 0xFF ;   // initialisation du code CRC octet bas (poids faible)
   while (nbOctPourCalcul-- > 0)  // passage des octets du message pour le calcul du CRC 
   {
      index = *crcBas ^ *pTable++ ;        // calcule le CRC
      *crcBas = *crcHaut ^ pgm_read_byte(&T_CRC_HAUT[index]) ; 
      *crcHaut = pgm_read_byte(&T_CRC_BAS[index]) ;
	}
}

//-------------------------------------------------------------------------------------------------
// DEBUG : Affiche les valeurs des variables dans un terminal
//-------------------------------------------------------------------------------------------------
void ModbusHD::z_test_A__mettre_a_1()
{
   pinMode(Z_TEST_PIN_A, OUTPUT);
   digitalWrite(Z_TEST_PIN_A, 1); // !!! test
}

void ModbusHD::z_test_A__mettre_a_0()
{
   pinMode(Z_TEST_PIN_A, OUTPUT);
   digitalWrite(Z_TEST_PIN_A, 0); // !!! test
}

void ModbusHD::z_test_A__basculer()
{
   pinMode(Z_TEST_PIN_A, OUTPUT);
   digitalWrite(Z_TEST_PIN_A, !digitalRead(Z_TEST_PIN_A)); // !!! test
}

void ModbusHD::z_test_B__mettre_a_1()
{
   pinMode(Z_TEST_PIN_B, OUTPUT);
   digitalWrite(Z_TEST_PIN_B, 1); // !!! test
}

void ModbusHD::z_test_B__mettre_a_0()
{
   pinMode(Z_TEST_PIN_B, OUTPUT);
   digitalWrite(Z_TEST_PIN_B, 0); // !!! test
}

void ModbusHD::z_test_B__basculer()
{
   pinMode(Z_TEST_PIN_B, OUTPUT);
   digitalWrite(Z_TEST_PIN_B, !digitalRead(Z_TEST_PIN_B)); // !!! test
}

// END OF FILE