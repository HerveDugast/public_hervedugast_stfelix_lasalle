/*-------------------------------------------------------------------------------------------------
Classe : Led.cpp           Version : 3.1           Version arduino : 1.6.5
Auteur : H. Dugast         Date : 24-04-2016
Fonction résumée : Commande une LED et gère les temps d'allumage et d'extinction
------------------------------------------------------------------------------------------------ */
#include <Led.h>

// ------------------------------------------------------------------------------------------------
// Public : Constructeur, prépare un objet Led
// Paramètres :
//    pinLed         -> numéro de broche commandant la led
//    niveauAllume   -> état logique qui allume la led : 0 ou 1
//    dureeEtatOn    -> durée de l'état Allumé de la led en ms
//    dureeEtatOff   -> durée de l'état Eteint de la led en ms
//    baseTemps      -> durée de la base de temps en ms
// ------------------------------------------------------------------------------------------------
Led::Led(uint8_t pinLed, bool niveauAllume, uint16_t dureeEtatOn, uint16_t dureeEtatOff):
   m_pinLed(pinLed), m_dureeEtatOn(dureeEtatOn), m_dureeEtatOff(dureeEtatOff),
   m_niveauAllume(niveauAllume)
{
   pinMode(m_pinLed, OUTPUT);                // configure la broche m_pinLed en SORTIE
   digitalWrite(m_pinLed, !m_niveauAllume);  // éteint la led

   m_isLedAllume = 0;                       // Led éteinte
   m_niveauActuel = !m_niveauAllume;
   m_dureeEtatOnEnCours = 0;
   m_dureeEtatOffEnCours = 0;
}

//-------------------------------------------------------------------------------------------------
// allume la led
//-------------------------------------------------------------------------------------------------
void Led::allumer()
{
   digitalWrite(m_pinLed, m_niveauAllume);  // allume la led
   m_isLedAllume = s_ALLUME;               // signale Led Allumee
   m_niveauActuel = s_ALLUME;               // mémorise état actuel
}

//-------------------------------------------------------------------------------------------------
// éteint la led
//-------------------------------------------------------------------------------------------------
void Led::eteindre()
{
   digitalWrite(m_pinLed, !m_niveauAllume); // éteint la led
   m_isLedAllume = !s_ALLUME;              // signale Led éteint
   m_niveauActuel = !s_ALLUME;              // mémorise état actuel
}

//-------------------------------------------------------------------------------------------------
// Change l'état de la led  (si Allumee -> ARRET  ou  si ARRET -> Allumee)
//-------------------------------------------------------------------------------------------------
void Led::changerEtat()
{
   m_niveauActuel = !digitalRead(m_pinLed);  // lit état Led puis prend l'autre état
   digitalWrite(m_pinLed, m_niveauActuel);   // change l'état de la led
   if (m_niveauActuel == m_niveauAllume)
      m_isLedAllume = s_ALLUME;            // signale Led Allumee
   else
      m_isLedAllume = !s_ALLUME;           // signale Led éteinte
}

//-------------------------------------------------------------------------------------------------
// Met à jour la durée d'allumage de la LED en ms
// Paramètres :
//    dureeEtatOn    -> durée de l'état Allumé de la led en ms
//-------------------------------------------------------------------------------------------------
void Led::setDureeEtatOn(uint16_t dureeEtatOn)
{
   m_dureeEtatOn = dureeEtatOn;
}

//-------------------------------------------------------------------------------------------------
// met à jour la durée d'extinction de la LED en ms
// Paramètres :
//    dureeEtatOff   -> durée de l'état Eteint de la led en ms
//-------------------------------------------------------------------------------------------------
void Led::setDureeEtatOff(uint16_t dureeEtatOff)
{
   m_dureeEtatOff = dureeEtatOff;
}

//-------------------------------------------------------------------------------------------------
// fait clignoter la led en fonction des durées d'allumage et d'extinction
// Attention, cette fonction a été écrite pour exécuter le moins d'instructions possibles à chaque 
// appel. Des simplifications pourraient être faites, mais cela ralentirait l'exécution du 
// programme.
//-------------------------------------------------------------------------------------------------
void Led::faireClignoter()
{
   static uint32_t millisDebutEtatOn = 0; // mémorise instant début allumage led
   static uint32_t millisDebutEtatOff = 0; // mémorise instant début extinction led
   uint32_t dureeEtatLed;   // durée en ms de l'état de la led en cours
   uint32_t periodeClignotement; // durée en ms état ON + durée état OFF
   // dureePeriodSautees utile quand dernier appel de la méthode faireClignoter supérieur à
   // période de clignotement
   uint32_t dureePeriodSautees;  // durée en ms des périodes de clignotement sautées

   periodeClignotement = m_dureeEtatOn + m_dureeEtatOff;
   if (isLedAllumee())
   {
      // led allumée
      dureeEtatLed = millis() - millisDebutEtatOn; // durée en ms de l'état Allumé de la led 

      // Vérification que cette fonction ait bien été appelé avant la fin de la période de
      // clignotement. Autrement dit, que la durée en cours de l'état de la led ne soit pas 
      // supérieur à la période de clignotement
      if (dureeEtatLed >= periodeClignotement)
      {
         // dernier appel de la méthode faireClignoter supérieur à période de clignotement
         // à éviter pour avoir des durées de clignotement correctes
         dureePeriodSautees = periodeClignotement * (dureeEtatLed / periodeClignotement);
         millisDebutEtatOn = millisDebutEtatOn + dureePeriodSautees; // rattrape temps sauté
         dureeEtatLed = dureeEtatLed - dureePeriodSautees;
      }
      // Détection fin allumage led
      if (dureeEtatLed >= m_dureeEtatOn)
      {
         eteindre();
         m_dureeEtatOnEnCours = 0;
         millisDebutEtatOff = millisDebutEtatOn + m_dureeEtatOn;
         //afficherVariableMembre();
      }
      else
         m_dureeEtatOnEnCours = millisDebutEtatOn + dureeEtatLed;
   }
   else
   {
      // led éteinte
      dureeEtatLed = millis() - millisDebutEtatOff; // durée en ms de l'état Eteint de la led 

      // Vérification que cette fonction ait bien été appelé avant la fin de la période de
      // clignotement. Autrement dit, que la durée en cours de l'état de la led ne soit pas 
      // supérieur à la période de clignotement
      if (dureeEtatLed >= periodeClignotement)
      {
         // dernier appel de la méthode faireClignoter supérieur à période de clignotement
         // à éviter pour avoir des durées de clignotement correctes
         // Très (trop) longtemps éteint, on allume immédiatement
         dureePeriodSautees = periodeClignotement * (dureeEtatLed / periodeClignotement);
         millisDebutEtatOn = millis(); // rattrape temps sauté
         m_dureeEtatOffEnCours = 0;
         allumer();
      }
      else
      {
         // Détection fin extinction led
         if (dureeEtatLed >= m_dureeEtatOff)
         {
            allumer();
            m_dureeEtatOffEnCours = 0;
            millisDebutEtatOn = millisDebutEtatOff + m_dureeEtatOff;
         }
         else
            m_dureeEtatOffEnCours = millisDebutEtatOff + dureeEtatLed;
      }
   }
}

//-------------------------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------
void Led::zClignotEteindreVerifier()
{

}

//-------------------------------------------------------------------------------------------------
// Debug : affiche le contenu des variables de l'objet
// Nécessite l'initialisation de la liaison série 0 dans le setup() :  Serial.begin(115200);
//-------------------------------------------------------------------------------------------------
void Led::afficherVariableMembre()
{
   Serial.println("");
   Serial.println("********** Variables membres objet Led *******************************");
   Serial.print("m_pinLed : "); Serial.println(m_pinLed);
   Serial.print("m_niveauActuel : "); Serial.println(m_niveauActuel);
   Serial.print("m_niveauAllume : "); Serial.println(m_niveauAllume);
   Serial.print("m_isLedAllume : "); Serial.println(m_isLedAllume);
   Serial.println("");
   Serial.print("m_dureeEtatOn (deci) : "); Serial.println(m_dureeEtatOn);
   Serial.print("m_dureeEtatOff (deci) : "); Serial.println(m_dureeEtatOff);
   Serial.print("m_dureeEtatOn (hexa) : "); Serial.println(m_dureeEtatOn, HEX);
   Serial.print("m_dureeEtatOff (hexa) : "); Serial.println(m_dureeEtatOff, HEX);
   Serial.print("m_dureeEtatOnEnCours : "); Serial.println(m_dureeEtatOnEnCours);
   Serial.print("m_dureeEtatOffEnCours : "); Serial.println(m_dureeEtatOffEnCours);
   Serial.println("********** Fin variables membres objet Led ***************************");
   Serial.println("");
}
