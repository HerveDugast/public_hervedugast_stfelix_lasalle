#pragma once
/*-------------------------------------------------------------------------------------------------
Classe : Led.h           Version : 3.1           Version arduino : 1.6.5
Auteur : H. Dugast         Date : 24-04-2016
Fonction résumée : Commande une LED et gère les temps d'allumage et d'extinction
------------------------------------------------------------------------------------------------ */
#include <Arduino.h>

class Led
{
public:
   // Constructeur, pour préparer un objet de type Led
   Led(uint8_t pinLed, bool niveauAllume, uint16_t dureeEtatOn, uint16_t dureeEtatOff);

   // allume la led
   void allumer();
   // stoppe la led
   void eteindre();
   // Change l'état de la led  (si ACTIF -> ARRET  ou  si ARRET -> ACTIF)
   void changerEtat();
   // fait clignoter la led en fonction des durées d'allumage et d'extinction
   void faireClignoter();


   // Retourne le niveau logique actuel envoyé sur la led (0 ou 1)
   bool getNiveauActuel() {return m_niveauActuel;}
   // retourne durée en ms d'un état Allumé
   uint16_t getDureeEtatOn() {return m_dureeEtatOn;}
   // retourne durée en ms d'un état Eteint
   uint16_t getDureeEtatOff() {return m_dureeEtatOff;}
   // retourne durée écoulée en ms depuis le début de l'allumage dans une phase de clignotement
   uint16_t getDureeEtatOnEnCours() { return m_dureeEtatOnEnCours; }
   // retourne durée écoulée en ms depuis le début de l'extinction dans une phase de clignotement
   uint16_t getDureeEtatOffEnCours() { return m_dureeEtatOffEnCours; }

   // Retourne le niveau logique qui active la led (0 ou 1)
   bool isLedAllumee() { return m_isLedAllume; }

   // met à jour la durée d'allumage de la LED en ms
   void setDureeEtatOn(uint16_t dureeEtatOn);
   // met à jour la durée d'extinction de la LED en ms
   void setDureeEtatOff(uint16_t dureeEtatOff);

   // Debug : affiche le contenu des variables de l'objet
   // Nécessite l'initialisation de la liaison série 0 dans le setup() :  Serial.begin(115200);
   void afficherVariableMembre();   

protected:
   // led allumée (allumée = 1), indépendant du niveau actif
   static const bool s_ALLUME = 1;
   // numéro de la broche qui est connectée à la led
   uint8_t m_pinLed;
   // niveau logique actuellement envoyé sur la led (0 ou 1)
   bool m_niveauActuel;
   // niveau logique (0 ou 1) qui allume la led
   bool m_niveauAllume;
   // valeur précisant si la led est allumée ou non (1:allumée  0:éteinte)
   bool m_isLedAllume;
   // durée état Allumé de la led en ms
   uint16_t m_dureeEtatOn;
   // durée état Eteint de la led en ms
   uint16_t m_dureeEtatOff;
   // durée écoulée depuis le début de l'état Allumé en ms
   uint16_t m_dureeEtatOnEnCours;
   // durée écoulée depuis le début de l'état Eteint en ms
   uint16_t m_dureeEtatOffEnCours;

   void zClignotEteindreVerifier();
};

