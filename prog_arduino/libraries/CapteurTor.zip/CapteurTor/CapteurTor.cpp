#pragma once
/*-------------------------------------------------------------------------------------------------
Classe :CapteurTor.cpp        Version : 1.3           Version arduino : 1.6.5
Auteur : H. Dugast            Date : 25-04-2016
Fonction résumée :
   - lit l'état logique présent sur l'entrée capteur avec un système anti-rebonds paramétrable
   - détecte et compte le nombre de fronts montants, descesdants arrivant sur l'entrée capteur
   - détecte et compte le nombre d'impulsions arrivant sur l'entrée capteur

Fonctionnement du système anti-rebonds :
   l'état logique retourné par la Classe CapteurTor lors d'une lecture de l'entrée capteur est
   un état stable, c'est-à-dire que cet état a eu le même niveau logique pendant la durée
   définie par le programme DUREE_MIN_ETAT_STABLE avec au moins 2 lectures. Cela permet de
   supprimer la phase transitoire d'un passage d'un état logique à un autre. Par exemple, cela
   supprime les rebonds mécaniques d'un bouton-poussoir lors de l'appui ou du relâchement.

 Exemple de capteurs : bouton_poussoir, interrupteur, signal d'entrée TOR 
 ----------------------------------------------------------------------------------------------- */
#include <CapteurTor.h>

// ------------------------------------------------------------------------------------------------
// Constructeur, prépare un objet CapteurTor sans fonction anti-rebonds
// Paramètres :
//    pinCapteurTor  -> numéro de broche connectée au capteur ou au signal TOR
// ------------------------------------------------------------------------------------------------
CapteurTor::CapteurTor(uint8_t pinCapteurTor): m_pinCapteurTor(pinCapteurTor)
{
   pinMode(m_pinCapteurTor, INPUT); // configure la broche en ENTREE
   m_niveauActif = 1;   // niveau actif par défaut
   resetImpulsionNbDureeEtDetect();
   resetFrontMontantNbEtDuree();
   resetFrontDescendantNbEtDuree();
   m_captDureeEtatStable = 0; // pas de gestion anti-rebonds

   // Niveau (0 ou 1) logique courant de l'état logique du capteur
   m_etatCourantNiveau = digitalRead(m_pinCapteurTor);
   // mémorise l'instant du début d'un nouvel état logique. Est donc mis à jour à chaque changement
   // d'état du capteur
   m_etatCourantInstantDebut = millis();
   // mémorise l'instant de la dernière lecture du capteur.
   m_etatCourantInstantDernLect = millis();
   // durée de l'état logique courant depuis son dernier changement
   m_etatCourantDuree = 0;
   // nombre d'états consécutifs lus ayant le même niveau logique
   m_etatCourantNbLect = 1;

   // Niveau (0 ou 1) logique courant de l'état logique du capteur
   m_etatStableNiveau = m_etatCourantNiveau;
   // durée de l'état logique courant depuis son dernier changement
   m_etatStableDuree = 0;
}

// ------------------------------------------------------------------------------------------------
// Constructeur, prépare un objet CapteurTor sans fonction anti-rebonds
// Paramètres :
//    pinCaptAnalog  -> numéro de broche connectée au potentiomètre
//    niveauActif    -> niveau logique du capteur ou signal considéré comme actif
// ------------------------------------------------------------------------------------------------
CapteurTor::CapteurTor(uint8_t pinCapteurTor, bool niveauActif) : 
   m_pinCapteurTor(pinCapteurTor), m_niveauActif(niveauActif)
{
   pinMode(m_pinCapteurTor, INPUT); // configure la broche en ENTREE
   resetImpulsionNbDureeEtDetect();
   resetFrontMontantNbEtDuree();
   resetFrontDescendantNbEtDuree();
   m_captDureeEtatStable = 0; // pas de gestion anti-rebonds

   // Niveau (0 ou 1) logique courant de l'état logique du capteur
   m_etatCourantNiveau = digitalRead(m_pinCapteurTor);
   // mémorise l'instant du début d'un nouvel état logique. Est donc mis à jour à chaque changement
   // d'état du capteur
   m_etatCourantInstantDebut = millis();
   // mémorise l'instant de la dernière lecture du capteur.
   m_etatCourantInstantDernLect = millis();
   // durée de l'état logique courant depuis son dernier changement
   m_etatCourantDuree = 0;
   // nombre d'états consécutifs lus ayant le même niveau logique
   m_etatCourantNbLect = 1;

   // Niveau (0 ou 1) logique courant de l'état logique du capteur
   m_etatStableNiveau = m_etatCourantNiveau;
   // durée de l'état logique courant depuis son dernier changement
   m_etatStableDuree = 0;
}

// ------------------------------------------------------------------------------------------------
// Constructeur, prépare un objet CapteurTor avec une gestion des anti-rebonds
// Paramètres :
//    pinCaptAnalog  -> numéro de broche connectée au potentiomètre
//    niveauActif    -> niveau logique du capteur ou signal considéré comme actif
//    captDureeEtatStable -> anti-rebonds, durée minimale en ms d'un état logique "stable"
// ------------------------------------------------------------------------------------------------
CapteurTor::CapteurTor(uint8_t pinCapteurTor, bool niveauActif, uint32_t captDureeEtatStable) :
   m_pinCapteurTor(pinCapteurTor), m_niveauActif(niveauActif), 
   m_captDureeEtatStable(captDureeEtatStable)
{
   pinMode(m_pinCapteurTor, INPUT); // configure la broche en ENTREE
   resetImpulsionNbDureeEtDetect();
   resetFrontMontantNbEtDuree();
   resetFrontDescendantNbEtDuree();

   // Niveau (0 ou 1) logique courant de l'état logique du capteur
   m_etatCourantNiveau = digitalRead(m_pinCapteurTor);
   // mémorise l'instant du début d'un nouvel état logique. Est donc mis à jour à chaque changement
   // d'état du capteur
   m_etatCourantInstantDebut = millis();
   // mémorise l'instant de la dernière lecture du capteur.
   m_etatCourantInstantDernLect = millis();
   // durée de l'état logique courant depuis son dernier changement
   m_etatCourantDuree = 0;
   // nombre d'états consécutifs lus ayant le même niveau logique
   m_etatCourantNbLect = 2;

   // Niveau (0 ou 1) logique courant de l'état logique du capteur
   m_etatStableNiveau = m_etatCourantNiveau;
   // durée de l'état logique courant stable
   m_etatStableDuree = m_etatCourantDuree;
}

// ------------------------------------------------------------------------------------------------
// indique si le signal délivré par le capteur est actif
//    Retour : bool -> 1 : capteur actif   0 : capteur inactif
// ------------------------------------------------------------------------------------------------
bool CapteurTor::isCapteurActif()
{
   lireCapteur();
   if (m_etatStableNiveau == m_niveauActif)
      return 1;
   else
      return 0;
}

// ------------------------------------------------------------------------------------------------
// lit l'état du capteur et signale si une impulsion a été détectée, 
// RAZ du drapeau après l'exécution de cette fonction
//    Retour : bool -> 1 : impulsion détectée (a eu lieu)   0 : pas d'impulsion détectée
// ------------------------------------------------------------------------------------------------
bool CapteurTor::isImpulsionDetectee()
{
   lireCapteur();
   if (m_impulsionIsDetect)
   {
      // impulsion détectée
      m_impulsionIsDetect = 0;
      return 1;
   }
   else
   {
      // pas d'impulsion détectée
      return 0;
   }
}

// ------------------------------------------------------------------------------------------------
// lit l'état du capteur et signale si un front montant a été détecté, 
// RAZ du drapeau après l'exécution de cette fonction
// ------------------------------------------------------------------------------------------------
bool CapteurTor::isFrontMontantDetecte()
{
   lireCapteur();
   if (m_frontMontIsDetect)
   {
      // front montant détecté
      m_frontMontIsDetect = 0;
      return 1;
   }
   else
   {
      // pas de front montant détecté
      return 0;
   }
}

// ------------------------------------------------------------------------------------------------
// lit l'état du capteur et signale si un front descendant a été détecté, 
// RAZ du drapeau après l'exécution de cette fonction
// ------------------------------------------------------------------------------------------------
bool CapteurTor::isFrontDescendantDetecte()
{
   lireCapteur();
   if (m_frontDescIsDetect)
   {
      // front montant détecté
      m_frontDescIsDetect = 0;
      return 1;
   }
   else
   {
      // pas de front montant détecté
      return 0;
   }
}

// ------------------------------------------------------------------------------------------------
// retourne la durée de comptage des impulsions en millisecondes à cet instant
// ------------------------------------------------------------------------------------------------
uint32_t CapteurTor::getImpulsionDureeDepuisDebutComptage()
{
   return millis() - m_impulsionInstantDebutComptage;
}

// ------------------------------------------------------------------------------------------------
// retourne la durée de comptage des fronts montants en millisecondes à cet instant
// ------------------------------------------------------------------------------------------------
uint32_t CapteurTor::getFrontMontantDureeDepuisDebutComptage()
{
   return millis() - m_frontMontInstantDebutComptage;
}

// ------------------------------------------------------------------------------------------------
// retourne la durée de comptage des fronts descendants en millisecondes à cet instant
// ------------------------------------------------------------------------------------------------
uint32_t CapteurTor::getFrontDescendantDureeDepuisDebutComptage()
{
   return millis() - m_frontDescInstantDebutComptage;
}

// ------------------------------------------------------------------------------------------------
// remet à 0 le compteur d'impulsions et réinitialise sa durée de comptage
// ------------------------------------------------------------------------------------------------
void CapteurTor::resetImpulsionNbDureeEtDetect()
{
   m_impulsionInstantDebutComptage = millis();
   m_impulsionNb = 0;
   m_impulsionIsDetect = 0;
   m_impulsionIsCommence = 0;
}

// ------------------------------------------------------------------------------------------------
// remet à 0 le compteur de fronts montants et réinitialise sa durée de comptage
// ------------------------------------------------------------------------------------------------
void CapteurTor::resetFrontMontantNbEtDuree()
{
   m_frontMontInstantDebutComptage = millis();
   m_frontMontNb = 0;
   m_frontMontIsDetect = 0;
}

// ------------------------------------------------------------------------------------------------
// remet à 0 le compteur de fronts descendants et réinitialise sa durée de comptage
// ------------------------------------------------------------------------------------------------
void CapteurTor::resetFrontDescendantNbEtDuree()
{
   m_frontDescInstantDebutComptage = millis();
   m_frontDescNb = 0;
   m_frontDescIsDetect = 0;
}

//-------------------------------------------------------------------------------------------------
// Affiche dans un terminal les variables membres de l'objet
//-------------------------------------------------------------------------------------------------
void CapteurTor::lireCapteur()
{
   m_etatCourantNiveauLectPrec = m_etatCourantNiveau; // mémorisation de l'état courant
   m_etatCourantNiveau = digitalRead(m_pinCapteurTor); // lecture état capteur
   if (m_etatCourantNiveau == m_etatCourantNiveauLectPrec)
   {
      // état logique capteur identique au dernier état logique lu
      m_etatCourantNbLect++;  // compte nombre d'états logiques identique
      m_etatCourantInstantDernLect = millis();  // mémorise instant lecture
      // calcule la durée de l'état logique en cours
      m_etatCourantDuree = m_etatCourantInstantDernLect - m_etatCourantInstantDebut;
      
      // pour détecter un état logique stable, il faut avoir le même état logique à chaque lecture 
      // pendant une durée supérieure ou égal à la durée définie m_captDureeEtatStable et avoir
      // effectué au moins 2 lectures, sauf si pas de gestion des rebonds mécaniques
      if ((m_etatCourantDuree >= m_captDureeEtatStable && m_etatCourantNbLect >= 2) ||
         (m_captDureeEtatStable == 0))
      {
         //Serial.println("====");
         //afficherVariableMembre();
         //delay(500);
         // état logique stable détecté
         if (m_etatCourantNiveau != m_etatStableNiveau)
         {
            // front détecté
            if (m_etatStableNiveau == 0)
            {
               //afficherVariableMembre();
               // front montant détecté
               m_frontMontIsDetect = 1;
               m_impulsionIsCommence = 1; // signale qu'une impusion vient de commencer
               m_frontMontNb++;
            }
            else
            {
               // front descendant détecté
               m_frontDescIsDetect = 1;
               m_frontDescNb++;
               if (m_impulsionIsCommence)
               {
                  // impulsion détectée (finalise la détection de l'impulsion)
                  m_impulsionIsDetect = 1;
                  m_impulsionNb++;
                  m_impulsionIsCommence = 0; // prépare prochaine détection impulsion
               }
            }
         }
         m_etatStableNiveau = m_etatCourantNiveau;
         m_etatStableDuree = m_etatCourantDuree; 
      }
   }
   else
   {
      m_etatCourantInstantDebut = millis();  // début d'un nouvel état logique
      m_etatCourantDuree = 0;
      m_etatCourantNbLect = 1;
   }
}

//-------------------------------------------------------------------------------------------------
// Affiche dans un terminal les variables membres de l'objet
//-------------------------------------------------------------------------------------------------
void CapteurTor::afficherVariableMembre()
{
   Serial.println("");
   Serial.println("********** Variables membres objet CapteurTor ************************");
   Serial.print("m_pinCapteurTor : "); Serial.println(m_pinCapteurTor);
   Serial.print("m_niveauActif : "); Serial.println(m_niveauActif);
   Serial.print("m_captDureeEtatStable : "); Serial.println(m_captDureeEtatStable);
   Serial.println("");
   Serial.print("m_impulsionNb : "); Serial.println(m_impulsionNb);
   Serial.print("m_impulsionInstantDebutComptage : "); 
   Serial.println(m_impulsionInstantDebutComptage);
   Serial.print("m_impulsionIsDetect : "); Serial.println(m_impulsionIsDetect);
   Serial.print("m_impulsionIsCommence : "); Serial.println(m_impulsionIsCommence);
   Serial.println("");
   Serial.print("m_frontMontNb : "); Serial.println(m_frontMontNb);
   Serial.print("m_frontMontInstantDebutComptage : "); 
   Serial.println(m_frontMontInstantDebutComptage);
   Serial.print("m_frontMontIsDetect : "); Serial.println(m_frontMontIsDetect);
   Serial.println("");
   Serial.print("m_frontDescNb : "); Serial.println(m_frontDescNb);
   Serial.print("m_frontDescInstantDebutComptage : ");
   Serial.println(m_frontDescInstantDebutComptage);
   Serial.print("m_frontDescIsDetect : "); Serial.println(m_frontDescIsDetect);
   Serial.println("");
   Serial.print("m_etatCourantInstantDebut : "); Serial.println(m_etatCourantInstantDebut);
   Serial.print("m_etatCourantInstantDernLect : "); Serial.println(m_etatCourantInstantDernLect);
   Serial.print("m_etatCourantNiveau : "); Serial.println(m_etatCourantNiveau);
   Serial.print("m_etatCourantNiveauLectPrec : "); Serial.println(m_etatCourantNiveauLectPrec);
   Serial.print("m_etatCourantDuree : "); Serial.println(m_etatCourantDuree);
   Serial.print("m_etatCourantNbLect : "); Serial.println(m_etatCourantNbLect);
   Serial.println("");
   Serial.print("m_etatStableNiveau : "); Serial.println(m_etatStableNiveau);
   Serial.print("m_etatStableDuree : "); Serial.println(m_etatStableDuree);
   Serial.println("********** Fin variables membres objet CapteurTor ********************");
   Serial.println("");
}
