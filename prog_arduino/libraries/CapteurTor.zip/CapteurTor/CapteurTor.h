#pragma once
/*-------------------------------------------------------------------------------------------------
Classe :CapteurTor.h          Version : 1.3           Version arduino : 1.6.5
Auteur : H. Dugast            Date : 25-04-2016
Fonction résumée :
   - lit l'état logique présent sur l'entrée capteur avec un système anti-rebonds paramétrable
   - détecte et compte le nombre de fronts montants, descesdants arrivant sur l'entrée capteur
   - détecte et compte le nombre d'impulsions arrivant sur l'entrée capteur

Fonctionnement du système anti-rebonds :
   l'état logique retourné par la Classe CapteurTor lors d'une lecture de l'entrée capteur est
   un état stable, c'est-à-dire que cet état a eu le même niveau logique pendant la durée
   définie par le programme DUREE_MIN_ETAT_STABLE avec au moins 2 lectures. Cela permet de
   supprimer la phase transitoire d'un passage d'un état logique à un autre. Par exemple, cela
   supprime les rebonds mécaniques d'un bouton-poussoir lors de l'appui ou du relâchement.

Exemple de capteurs : bouton_poussoir, interrupteur, signal d'entrée TOR
------------------------------------------------------------------------------------------------ */
#include <Arduino.h>

class CapteurTor
{
public:
   // Constructeur pour objet de type capteur TOR (Tout ou Rien), comme un bouton-poussoir
   CapteurTor(uint8_t pinCapteurTor);
   // Constructeur pour objet de type capteur TOR (Tout ou Rien), comme un bouton-poussoir
   CapteurTor(uint8_t pinCapteurTor, bool niveauActif);
   // Constructeur pour objet de type capteur TOR (Tout ou Rien), comme un bouton-poussoir
   CapteurTor(uint8_t pinCapteurTor, bool niveauActif, uint32_t captDureeEtatStable);

   // indique si le signal délivré par le capteur est actif
   bool isCapteurActif();
   // lit l'état du capteur et signale si une impulsion a été détectée, 
   // RAZ du drapeau après l'exécution de cette fonction
   bool isImpulsionDetectee();
   // signale qu'un front montant a été détecté, RAZ du drapeau après l'exécution de cette fonction
   bool isFrontMontantDetecte();
   // signale qu'un front descendant a été détecté, RAZ du drapeau après l'exécution de cette
   // fonction
   bool isFrontDescendantDetecte();

   // retourne le nombre d'impulsions détectées depuis le dernier RAZ
   uint32_t getImpulsionNombre() { return m_impulsionNb; }
   // retourne la durée de comptage des impulsions en millisecondes à cet instant
   uint32_t getImpulsionDureeDepuisDebutComptage();

   // retourne le nombre de fronts montants détectés depuis le dernier RAZ
   uint32_t getFrontMontantNombre() { return m_frontMontNb; }
   // retourne la durée de comptage des fronts montants en millisecondes à cet instant
   uint32_t getFrontMontantDureeDepuisDebutComptage();

   // retourne le nombre de fronts descendants détectés depuis le dernier RAZ
   uint32_t getFrontDescendantNombre() { return m_frontDescNb; }
   // retourne la durée de comptage des fronts descendants en millisecondes à cet instant
   uint32_t getFrontDescendantDureeDepuisDebutComptage();

   // retourne l'état stable en cours
   bool getEtatStableEnCours() { return m_etatStableNiveau; }
   
   // remet à 0 le compteur d'impulsions et réinitialise sa durée de comptage
   void resetImpulsionNbDureeEtDetect();
   // remet à 0 le compteur de fronts montants et réinitialise sa durée de comptage
   void resetFrontMontantNbEtDuree();
   // remet à 0 le compteur de fronts descendants et réinitialise sa durée de comptage
   void resetFrontDescendantNbEtDuree();

   // Affiche dans un terminal les variables membres de l'objet
   void lireCapteur();
   // Affiche dans un terminal les variables membres de l'objet
   void afficherVariableMembre();

protected:
   // numéro de la broche qui est connectée au capteur TOR
   uint8_t m_pinCapteurTor;
   // niveau actif du capteur TOR
   bool m_niveauActif;
   // anti-rebonds, durée minimale en ms d'un état logique pour qu'il soit considéré comme stable
   uint32_t m_captDureeEtatStable;

   // compte le nombre d'impulsions depuis le dernier RAZ.
   // impulsion -> détection passages : niveau inactif - niveau actif momentané - niveau inactif
   uint32_t m_impulsionNb;
   // mémorise le nombre de millisecondes écoulées (fonction millis) au début du comptage
   uint32_t m_impulsionInstantDebutComptage;
   // signale qu'une impulsion vient d'être détecté. RAZ à chaque lecture de cette variable
   bool m_impulsionIsDetect;
   // signale le début d'une impulsion
   bool m_impulsionIsCommence = 0;

   // compte le nombre de fronts montants depuis le dernier RAZ.
   // front montant -> détection passages : niveau bas - niveau haut
   uint32_t m_frontMontNb;
   // mémorise le nombre de millisecondes écoulées (fonction millis) au début du comptage
   uint32_t m_frontMontInstantDebutComptage;
   // signale qu'un front montant vient d'être détecté. RAZ à chaque lecture de cette variable
   bool m_frontMontIsDetect;

   // compte le nombre de fronts descendants depuis le dernier RAZ.
   // front descendant -> détection passages : niveau haut - niveau bas
   uint32_t m_frontDescNb;
   // mémorise le nombre de millisecondes écoulées (fonction millis) au début du comptage
   uint32_t m_frontDescInstantDebutComptage;
   // signale qu'un front descendant vient d'être détecté. RAZ à chaque lecture de cette variable
   bool m_frontDescIsDetect;

   // mémorise l'instant du début d'un nouvel état logique. Est donc mis à jour à chaque changement
   // d'état du capteur
   uint32_t m_etatCourantInstantDebut;
   // mémorise l'instant de la dernière lecture du capteur.
   uint32_t m_etatCourantInstantDernLect;
   // Niveau (0 ou 1) logique courant de l'état logique du capteur
   bool m_etatCourantNiveau;
   // Précédent état logique lu lors de la dernière lecture du capteur
   bool m_etatCourantNiveauLectPrec;
   // durée de l'état logique courant depuis son dernier changement
   uint32_t m_etatCourantDuree;
   // nombre d'états consécutifs lus ayant le même niveau logique
   uint32_t m_etatCourantNbLect;

   // Niveau (0 ou 1) logique stable (plus de rebonds mécaniques)
   bool m_etatStableNiveau;
   // durée de l'état logique stable
   uint32_t m_etatStableDuree;

   //// compte le nombre de fronts descendants depuis le dernier RAZ.
   //// front montant -> détection passages : niveau bas - niveau haut
   //uint32_t m_frontDescNb;
   //// mémorise le nombre de millisecondes écoulées (fonction millis) au début du comptage
   //uint32_t m_frontDescInstantDebutComptage;
   //// signale qu'un front montant vient d'être détecté. RAZ à chaque lecture de cette variable
   //bool m_frontDescIsDetect = 0;


private:
};

