﻿#pragma once
/*-------------------------------------------------------------------------------------------------
Classe : XBeeGestion.h        Version : 3.0           Version arduino : 1.6.5
Auteur : H. Dugast            Date : 20-04-2016
Fonction résumée : Gère une communication zigBee
Remarque : cette bibliothèque n'est pas optimisée par manque de temps
------------------------------------------------------------------------------------------------ */
#include <Xbee.h>
#include <PString.h>

#define BUF_SIZE 100
#define DATA_SIZE_RX 21
#define MAX_PAYLOAD 74

class XbeeGestion
{
public:
   // Constructeur, pour préparer un objet de type XBee
   XbeeGestion();
   XbeeGestion(int portSerieXbee, uint32_t baudrate);
   XbeeGestion(const XBeeAddress64 &addr64Dest, int portSerieXbee, uint32_t baudrate);
   XbeeGestion(const XBeeAddress64 &addr64Dest, uint8_t *data, uint8_t dataLength,
      int portSerieXbee, uint32_t baudrate);
   XbeeGestion(const XBeeAddress64 &addr64Dest, uint8_t *data, uint8_t dataLength,
      int portSerieXbee, uint32_t baudrate, uint8_t pinLedSend, uint8_t pinLedReceive, uint8_t pinLedError);
   XbeeGestion(const XBeeAddress64 &addr64Dest, uint8_t *data, uint8_t dataLength,
      int portSerieXbee, uint32_t baudrate, uint8_t pinLedSend, uint8_t pinLedReceive, uint8_t pinLedError,
      uint8_t pinSend, uint8_t pinReceipt);
   void init();
   bool getPacket(int timeout);

   //	PString startNewSendBufferWriter();
   ZBRxResponse& getLastZBRxResponse();

   XBeeAddress64& getDefaultDestinationAddress();
   void setDefaultDestinationAddress(XBeeAddress64& addr);

   int send();
   int send(XBeeAddress64 to);

   char * getDataHexChain() { return m_dataRxChainHex; }
   uint8_t getNbDataHexChain() { return m_nbDataRxChainHex; }
   uint8_t getDataOctet(uint8_t i) { return m_dataRxOctet[i]; }
   uint8_t getNbDataOctet() { return m_nbDataRxOctet; }
   uint8_t getErreurXbeeCode() { return m_errXbeeCode; }
   char * getErreurXbeeNom() { return m_errXbeeNom; }
   uint8_t getCommandAT(uint8_t num) { return m_cmdAt[num]; }
   uint32_t getDestinationAddressMsb() { return m_myAddrMsb; }
   uint32_t getDestinationAddressLsb() { return m_myAddrLsb; }

   void setCommandeAt(uint8_t cmdAt1, uint8_t cmdAt2);
   void setErreurXbeeCode(uint8_t errXbeeCode) { m_errXbeeCode = errXbeeCode; }
   uint8_t envoyerCmdATetGererReponse();

   // Lit à l'aide de commandes AT (encapsulés dans trame API) les paramètres du module XBee connecté.
   // Utilise le port Serial1 pour communiquer avec le module XBee puis le port Serial0 pour afficher
   // les informations dans un terminal.
   void afficherInfoXbee();
   // Exécute puis affiche les données retournées par une commande AT
   void executerCommandeAT(uint8_t cmdAt1, uint8_t cmdAt2);
   void afficherVariableMembre();
   // Envoie une trame API de type ZBTxRequest vers le module XBee pour émission radio
   // Récupère l'accusé de réception envoyé par le module Xbee destinataire
   // Signale les éventuelles erreurs qui se sont produites lors des échanges
   void envoyerZBTxRequestEtReceptionnerAR();
   // Réceptionne une trame API de type ZBTxRequest, récupère les données utiles puis envoie un 
   // accusé de réception. Signale les éventuelles erreurs qui se sont produites lors des échanges
   void recevoirAvecZBRxResponseEtEnvoyerAR();
   // Affiche la trame API de type ZBTxRequest réceptionnée, Réponse stockée dans objet m_rx 
   // (ZBRxResponse)
   void afficherTrameZBRxResponse();
   // Affiche la trame envoyée par le module XBee distant, t donc réceptionnée par le XBee local
   // (XBee distant répond à une trame API envoyée juste avant par le XBee local)
   void afficherTrameZBTxStatusResponse();
   // Affiche la trame envoyée par la carte arduino au module XBee local, qui l'enverra ensuite
   // par liaison radio au module XBee distant
   void afficherTrameZBTxRequest();
   
   void signalerErreurCommunication();
   // Signale une erreur quand aucun paquet Xbee n'a été reçu pendant une durée donnée. Autrement
   // dit : durée en ms max entre 2 réceptions de paquet. Lorsque cette durée est dépassée, une erreur
   // est signalée.
   void signalerProblemeReceptionPaquet(int dureeMaxSansPaquet);
   // retourne 1 si une erreur est détectée, sinon retourne 0
   bool isError();

   // Vide le buffer de réception du port série connecté au Xbee
   void viderBufferReceptionPortSerie();


   void allumerLedEmission();
   void eteindreLedEmission();
   void changerEtatLedEmission();

   void allumerLedReception();
   void eteindreLedReception();
   void changerEtatLedReception();

   // allume la led erreur communication xbee
   void allumerLedErreurXbee();
   // éteint la led erreur communication xbee
   void eteindreLedErreurXbee();
   // change d'état la led erreur communication xbee
   void changerEtatLedErreurXbee();



   // Signal de synchro pour chaque envoi de trame : front montant
   void envoyerSignalSend__mettre_a_1();
   // Signal de synchro pour chaque envoi de trame : front descendant
   void envoyerSignalSend__mettre_a_0();
   // Signal de synchro pour chaque envoi de trame : basculement
   void envoyerSignalSend__basculer();
   // Signal de synchro pour chaque envoi de trame : front montant
   void envoyerSignalReceive__mettre_a_1();
   // Signal de synchro pour chaque envoi de trame : front descendant
   void envoyerSignalReceive__mettre_a_0();
   // Signal de synchro pour chaque envoi de trame : basculement
   void envoyerSignalReceive__basculer();

   // objet XBee
   XBee m_xbee;
   // objet pour gérer trame API de type ZBTxRequest
   ZBTxRequest m_zbTx;
   // objet pour gérer l'accusé de réception de la trame API envoyée
   ZBTxStatusResponse m_txStatus;
   // objet pour réceptionner une trame API de type ZBTxRequest la réception l'accusé de réception de la trame API envoyée
   ZBRxResponse m_rx;


private:
   // Erreur dans la réponse commande AT
   static const char * s_AUCUNE_ERR;
   // Erreur dans la réponse commande AT
   static const char * s_ERR_REP_AT;
   // Erreur dans le type de trame réceptionné
   static const char * s_ERR_TYP_TRAM;
   // Erreur dans la commande AT ou lecture paquet
   static const char * s_ERR_PAQU_AT;
   // Erreur pas de réponse du module m_xbee
   static const char * s_ERR_XBEE_OFF;
   // Erreur réception : durée max pour recevoir un message utilisateur dépassée
   static const char * s_ERR_RECEPTION;

   // adresse 64 bits de destination (DH, DL)
   XBeeAddress64 m_myOwner;
   uint32_t m_myAddrMsb;
   uint32_t m_myAddrLsb;
   boolean m_isSending;
   uint8_t m_sendBuffer[BUF_SIZE];

   // numéro port série arduino connecté à Xbee
   uint8_t m_portSerieXbee; 
   uint8_t m_pinLedSend;
   uint8_t m_pinLedReceive;
   uint8_t m_pinLedError;
   uint8_t m_pinSend;
   uint8_t m_pinReceipt;

   // tableau, champ data RF de la réponse en octets transformées en chaine de caract. hexa
   char m_dataRxChainHex[DATA_SIZE_RX];
   // longueur de la chaine de caract. réponse hexa
   uint8_t m_nbDataRxChainHex;
   // tableau, champ data RF de la réponse en octets
   uint8_t m_dataRxOctet[DATA_SIZE_RX];
   // nb d'octets contenus dans la réponse
   uint8_t m_nbDataRxOctet;
   // numéro de l'erreur retourné suite à la transmission (0:pas d'erreur, 1 ou plus: erreur)
   uint8_t m_errXbeeCode;
   // nom simplifié de l'erreur
   char m_errXbeeNom[14];
   // mémorisation instant (en ms) de la derniere réception d'un message par la liaison Xbee
   // sert à détecter les pb de réception et signaler l'erreur "ERR reception"
   // -> pas de message de message utilisateur reçue depuis la durée définie
   unsigned long m_millisStartDetectPbReceipt;

   uint8_t m_cmdAt[2];

   // paquet Tx (trame API) contenant une commande AT pour configurer XBee local
   AtCommandRequest m_atRequest;
   // paquet Rx (trame API) contenant la réponse du module XBee local à la commande AT
   AtCommandResponse m_atResponse;

   uint32_t xbeeArrayToHostUInt32(uint8_t* buf, int len);
   // convertir type unsigned long en hexa puis en chaine de caractères
   //   void ulongToChaineHex(uint32_t nombre, char * buffer);

   void effacerData();
};

