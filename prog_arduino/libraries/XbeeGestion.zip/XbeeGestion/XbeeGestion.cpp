#pragma once
/*-------------------------------------------------------------------------------------------------
Classe : XBeeGestion.cpp      Version : 3.0           Version arduino : 1.6.5
Auteur : H. Dugast            Date : 20-04-2016
Fonction résumée : Gère une communication zigBee
Remarque : cette bibliothèque n'est pas optimisée par manque de temps
------------------------------------------------------------------------------------------------ */
#include <PString.h>
#include <XbeeGestion.h>

// attente réponse xbee distant suite à l'envoi d'une trame par le xbee local (zbTx)
const int DUREE_ATTENTE_REPONSE = 50; 

// Aucune Erreur dans la réponse commande AT
const char * XbeeGestion::s_AUCUNE_ERR = "Aucune Err";
// Erreur dans la réponse commande AT
const char * XbeeGestion::s_ERR_REP_AT = "ERR rep AT";
// Erreur dans le type de trame réceptionné
const char * XbeeGestion::s_ERR_TYP_TRAM = "ERR typ tram";
// Erreur dans la commande AT ou lecture paquet
const char * XbeeGestion::s_ERR_PAQU_AT = "ERR paqu AT";
// Erreur pas de réponse du module xbee
const char * XbeeGestion::s_ERR_XBEE_OFF = "ERR commXBee";
// Erreur réception : durée max pour recevoir un message utilisateur dépassée
const char * XbeeGestion::s_ERR_RECEPTION = "ERR reception";

//-------------------------------------------------------------------------------------------------
// Constructeurs
//-------------------------------------------------------------------------------------------------
XbeeGestion::XbeeGestion() : m_xbee(), m_myOwner(0x0013a200, 0x0), 
m_myAddrMsb(0x0013a200), m_myAddrLsb(0x0), m_isSending(false), m_rx()
{
   m_pinLedSend = 99;      // pas de led
   m_pinLedReceive = 99;   // pas de led
   m_pinLedError = 99;     // pas de led
   m_pinSend = 99;         // signal synchro envoi non utilisé
   m_pinReceipt = 99;      // signal synchro réception non utilisé
   m_portSerieXbee = 1;    // port série par défaut pour communiquer avec le Xbee
   effacerData();
}

XbeeGestion::XbeeGestion(int portSerieXbee, uint32_t baudrate) :
   m_xbee(), m_isSending(false), m_rx(), m_portSerieXbee(portSerieXbee), m_myOwner(0x0013a200,
      0x0), m_myAddrMsb(0x0013a200), m_myAddrLsb(0x0)
{
   if (portSerieXbee == 0)
   {
      Serial.begin(baudrate);
      m_xbee.setSerial(Serial);
   }
   else if (portSerieXbee == 1)
   {
#if defined(UBRR1H)  // vérifie que le port série 1 existe bien
      Serial1.begin(baudrate);
      m_xbee.setSerial(Serial1);
#endif 
   }
   m_pinLedSend = 99;      // pas de led
   m_pinLedReceive = 99;   // pas de led
   m_pinLedError = 99;     // pas de led
   m_pinSend = 99;         // signal synchro envoi non utilisé
   m_pinReceipt = 99;      // signal synchro réception non utilisé
   m_millisStartDetectPbReceipt = millis(); // débute durée détection erreur sans réception Xbee
   effacerData();
}

XbeeGestion::XbeeGestion(const XBeeAddress64 &addr64Dest, int portSerieXbee, uint32_t baudrate) :
   m_xbee(), m_myOwner(addr64Dest), m_isSending(false), m_rx(), m_portSerieXbee(portSerieXbee)
{
   m_myAddrMsb = m_myOwner.getMsb();
   m_myAddrLsb = m_myOwner.getLsb();
   if (portSerieXbee == 0)
   {
      Serial.begin(baudrate);
      m_xbee.setSerial(Serial);
   }
   else if (portSerieXbee == 1)
   {
#if defined(UBRR1H)  // vérifie que le port série 1 existe bien
      Serial1.begin(baudrate);
      m_xbee.setSerial(Serial1);
#endif 
   }
   m_pinLedSend = 99;      // pas de led
   m_pinLedReceive = 99;   // pas de led
   m_pinLedError = 99;     // pas de led
   m_pinSend = 99;         // signal synchro envoi non utilisé
   m_pinReceipt = 99;      // signal synchro réception non utilisé
   m_millisStartDetectPbReceipt = millis(); // débute durée détection erreur sans réception Xbee
   effacerData();
}

XbeeGestion::XbeeGestion(const XBeeAddress64 &addr64Dest, uint8_t *data, uint8_t dataLength, 
   int portSerieXbee, uint32_t baudrate) :
   m_xbee(), m_myOwner(addr64Dest), m_myAddrMsb(0x0013a200), m_myAddrLsb(0x0), m_isSending(false),
   m_rx(), m_zbTx(addr64Dest, data, dataLength), m_txStatus(), m_portSerieXbee(portSerieXbee)
{
   m_myAddrMsb = m_myOwner.getMsb();
   m_myAddrLsb = m_myOwner.getLsb();
   if (portSerieXbee == 0)
   {
      Serial.begin(baudrate);
      m_xbee.setSerial(Serial);
   }
   else if (portSerieXbee == 1)
   {
      #if defined(UBRR1H)  // vérifie que le port série 1 existe bien
         Serial1.begin(baudrate);
         m_xbee.setSerial(Serial1);
      #endif 
   }
   m_pinLedSend = 99;      // pas de led
   m_pinLedReceive = 99;   // pas de led
   m_pinLedError = 99;     // pas de led
   m_pinSend = 99;         // signal synchro envoi non utilisé
   m_pinReceipt = 99;      // signal synchro réception non utilisé
   m_millisStartDetectPbReceipt = millis(); // débute durée détection erreur sans réception Xbee
   effacerData();
}

XbeeGestion::XbeeGestion(const XBeeAddress64 &addr64Dest, uint8_t *data, uint8_t dataLength,
   int portSerieXbee, uint32_t baudrate, uint8_t pinLedSend, uint8_t pinLedReceive, uint8_t pinLedError) :
   m_xbee(), m_myOwner(addr64Dest), m_isSending(false), m_rx(), m_zbTx(addr64Dest, data, dataLength),
   m_txStatus(), m_portSerieXbee(portSerieXbee)
{
   m_myAddrMsb = m_myOwner.getMsb();
   m_myAddrLsb = m_myOwner.getLsb();
   if (portSerieXbee == 0)
   {
      Serial.begin(baudrate);
      m_xbee.setSerial(Serial);
   }
   else if (portSerieXbee == 1)
   {
#if defined(UBRR1H)  // vérifie que le port série 1 existe bien
      Serial1.begin(baudrate);
      m_xbee.setSerial(Serial1);
#endif 
   }
   m_pinLedSend = pinLedSend;          // led émission trame
   pinMode(m_pinLedSend, OUTPUT);      // configure la broche en SORTIE
   m_pinLedReceive = pinLedReceive;    // led réception trame
   pinMode(m_pinLedReceive, OUTPUT);   // configure la broche en SORTIE
   m_pinLedError = pinLedError;        // led erreur communication zigbee
   pinMode(m_pinLedError, OUTPUT);      // configure la broche en SORTIE
   m_pinSend = 99;      // signal synchro envoi non utilisé
   m_pinReceipt = 99;   // signal synchro réception non utilisé
   m_millisStartDetectPbReceipt = millis(); // débute durée détection erreur sans réception Xbee
   effacerData();
}

XbeeGestion::XbeeGestion(const XBeeAddress64 &addr64Dest, uint8_t *data, uint8_t dataLength,
   int portSerieXbee, uint32_t baudrate, uint8_t pinLedSend, uint8_t pinLedReceive, uint8_t pinLedError,
   uint8_t pinSend, uint8_t pinReceipt) :
   m_xbee(), m_myOwner(addr64Dest), m_isSending(false), m_rx(), m_zbTx(addr64Dest, data, dataLength),
   m_txStatus(), m_portSerieXbee(portSerieXbee)
{
   m_myAddrMsb = m_myOwner.getMsb();
   m_myAddrLsb = m_myOwner.getLsb();
   if (portSerieXbee == 0)
   {
      Serial.begin(baudrate);
      m_xbee.setSerial(Serial);
   }
   else if (portSerieXbee == 1)
   {
#if defined(UBRR1H)  // vérifie que le port série 1 existe bien
      Serial1.begin(baudrate);
      m_xbee.setSerial(Serial1);
#endif 
   }

   m_pinLedSend = pinLedSend;          // led émission trame
   pinMode(m_pinLedSend, OUTPUT);      // configure la broche en SORTIE
   m_pinLedReceive = pinLedReceive;    // led réception trame
   pinMode(m_pinLedReceive, OUTPUT);   // configure la broche en SORTIE
   m_pinLedError = pinLedError;        // led erreur communication zigbee
   pinMode(m_pinLedError, OUTPUT);     // configure la broche en SORTIE
   m_pinSend = pinSend;             // signal synchro envoi
   pinMode(m_pinSend, OUTPUT);      // configure la broche en SORTIE
   m_pinReceipt = pinReceipt;       // signal synchro réception
   pinMode(m_pinReceipt, OUTPUT);   // configure la broche en SORTIE
   m_millisStartDetectPbReceipt = millis(); // débute durée détection erreur sans réception Xbee
   effacerData();
}

//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
void XbeeGestion::init()
{
   uint8_t cmd[] = { 'S', 'L' };
   AtCommandRequest addrRequest = AtCommandRequest(cmd);
   m_xbee.send(addrRequest);
   m_isSending = true;
}

/*
PString XbeeGestion::startNewSendBufferWriter()
{
return PString((char*)m_sendBuffer, sizeof(m_sendBuffer));
}
*/

ZBRxResponse& XbeeGestion::getLastZBRxResponse()
{
   return m_rx;
}

XBeeAddress64& XbeeGestion::getDefaultDestinationAddress()
{
   return m_myOwner;
}

void XbeeGestion::setDefaultDestinationAddress(XBeeAddress64& addr)
{
   m_myOwner.setMsb(addr.getMsb());
   m_myOwner.setLsb(addr.getLsb());
}

bool XbeeGestion::getPacket(int timeout)
{
   if (timeout <= 0) m_xbee.readPacket();
   else m_xbee.readPacket(timeout);

   XBeeResponse& resp = m_xbee.getResponse();
   if (resp.isAvailable())
   {
      if (resp.getApiId() == ZB_RX_RESPONSE)
      {
         resp.getZBRxResponse(m_rx);
         //if(m_rx.getOption() == ZB_PACKET_ACKNOWLEDGED) return;
         //handlePacket(m_rx);
         return true;
      }
      else if (resp.getApiId() == AT_COMMAND_RESPONSE)
      {
         m_isSending = false;

         AtCommandResponse atResp = AtCommandResponse();
         resp.getAtCommandResponse(atResp);
         if (!atResp.isOk())
            return false;
         if (atResp.getCommand()[0] == 'S' && atResp.getCommand()[1] == 'L')
         {
            m_myAddrLsb = xbeeArrayToHostUInt32(atResp.getValue(),
               atResp.getValueLength());
         }
      }
      else if (resp.getApiId() == ZB_TX_STATUS_RESPONSE)
      {
         ZBTxStatusResponse txStatus = ZBTxStatusResponse();
         resp.getZBTxStatusResponse(txStatus);
         if (m_txStatus.getDeliveryStatus() == SUCCESS) {
            m_zbTx.setFrameId(m_xbee.getNextFrameId());

         }
         else if (m_txStatus.getDeliveryStatus() == PAYLOAD_TOO_LARGE)
         {
         }
         m_isSending = false;
      }
      else
      {
         PString pWriter((char*)m_sendBuffer, sizeof(m_sendBuffer));
         pWriter.print("{\"msgType\": -1, \"error\": \"unknown id: ");
         pWriter.print(resp.getApiId(), DEC);
         pWriter.print("\"}");

         if (m_myOwner.getLsb() != 0) {
            send(m_myOwner);
         }
      }
   }
   else if (resp.isError()) {
      PString pWriter((char*)m_sendBuffer, sizeof(m_sendBuffer));
      pWriter.print(
         "{\"msgType\": -1, \"error\": \"Packet error\", \"code\":");
      pWriter.print(resp.getErrorCode());
      pWriter.print("}");

      m_isSending = false;


      if (m_myOwner.getLsb() != 0) {
         send();
      }
   }
   else if (m_isSending)
   {
      // Do Nothing... timeout probably happened
      m_isSending = false;
      PString pWriter((char*)m_sendBuffer, sizeof(m_sendBuffer));
      pWriter.print("{\"msgType\": -1, \"error\": \"unable to transmit. load too large?\"}");
      send();
   }
   return false;
}

int XbeeGestion::send()
{
   return send(m_myOwner);
}

int XbeeGestion::send(XBeeAddress64 to)
{
   if (m_isSending)
   {
      return -1; //We have to wait for a success on the current frame... probably
   }

   m_zbTx = ZBTxRequest(to, m_sendBuffer, strlen((const char*)m_sendBuffer));
   m_xbee.send(m_zbTx);
   m_isSending = true;
   return 0;
}

uint32_t XbeeGestion::xbeeArrayToHostUInt32(uint8_t* buf, int len)
{
   uint32_t result = 0;

   for (int i = 0; i < len; i++) {
      result <<= 8;
      result += buf[i];
   }
   return result;
}

//-------------------------------------------------------------------------------------------------
// Envoie une commande AT au module XBee local pour le configurer
// Retour : 
//    uint8_t -> code erreur retourné lors de la réponse du module XBee ou suite à l'émission
//                0 : pas d'erreur     1 ou plus : erreur
//-------------------------------------------------------------------------------------------------
void XbeeGestion::setCommandeAt(uint8_t cmdAt1, uint8_t cmdAt2)
{
   m_cmdAt[0] = cmdAt1;
   m_cmdAt[1] = cmdAt2;
   m_atRequest.setCommand(m_cmdAt);
}

//-------------------------------------------------------------------------------------------------
// Envoie une commande AT au module XBee local pour le configurer
// Retour : 
//    uint8_t -> code erreur retourné lors de la réponse du module XBee ou suite à l'émission
//                0 : pas d'erreur     1 ou plus : erreur
//-------------------------------------------------------------------------------------------------
uint8_t XbeeGestion::envoyerCmdATetGererReponse()
{
   int i;
   m_xbee.readPacket();  // vide le buffer de réception, utile si une erreur a eu lieu précédemment
   m_xbee.send(m_atRequest);   // envoie la commande AT

   effacerData();

   // attends DUREE_ATTENTE_REPONSE max en ms le statut de la réponse
   if (m_xbee.readPacket(DUREE_ATTENTE_REPONSE))
   {
      // réponse reçue !

      // doit être une réponse de commande AT
      if (m_xbee.getResponse().getApiId() == AT_COMMAND_RESPONSE)
      {
         m_xbee.getResponse().getAtCommandResponse(m_atResponse);
         if (m_pinSend != 99)  envoyerSignalSend__mettre_a_1(); // front montant signal syncho envoi trame
         //if (m_pinLedSend != 99)  allumerLedEmission(); 

         if (m_atResponse.isOk())
         {
            // nb de valeurs à récupérer dans la réponse
            m_nbDataRxOctet = m_atResponse.getValueLength();
            if (m_nbDataRxOctet > 0)
            {
               // récupère les valeurs (octets) de la réponse
               for (i = 0; i < m_nbDataRxOctet; i++)
               {
                  m_dataRxOctet[i] = m_atResponse.getValue()[i];
                  sprintf(&m_dataRxChainHex[2 * i], "%02hx", m_dataRxOctet[i]);
               }
               m_nbDataRxChainHex = 2 * i;
               m_dataRxChainHex[m_nbDataRxChainHex] = '\0';
            }
         }
         else
         {
            // erreur dans la réponse AT
            strcpy(m_errXbeeNom, s_ERR_REP_AT);
            m_errXbeeCode = m_atResponse.getStatus();
         }
         if (m_pinSend != 99)  envoyerSignalSend__mettre_a_0(); // front descendant signal syncho envoi trame
         //if (m_pinLedSend != 99)  eteindreLedEmission();
      }
      else
      {
         // erreur dans le type trame réceptionné
         strcpy(m_errXbeeNom, s_ERR_TYP_TRAM); // copie (const char *) dans (char *)
         m_errXbeeCode = m_xbee.getResponse().getApiId();
      }
   }
   else
   {
      // erreur dans la commande AT ou lecture paquet
      if (m_xbee.getResponse().isError())
      {
         strcpy(m_errXbeeNom, s_ERR_PAQU_AT);
         m_errXbeeCode = m_xbee.getResponse().getErrorCode();
      }
      else
      {
         strcpy(m_errXbeeNom, s_ERR_XBEE_OFF);
         m_errXbeeCode = 0xFF;
      }
   }
   signalerErreurCommunication(); // allume led Erreur Communication Xbee en cas d'erreur
   return m_errXbeeCode;
}

//-------------------------------------------------------------------------------------------------
// Envoie une trame API de type ZBTxRequest vers le module XBee pour émission radio
// Récupère l'accusé de réception envoyé par le module Xbee destinataire
// Signale les éventuelles erreurs qui se sont produites lors des échanges
//-------------------------------------------------------------------------------------------------
void XbeeGestion::envoyerZBTxRequestEtReceptionnerAR()
{
   unsigned long start;
   if (m_pinSend != 99) envoyerSignalSend__mettre_a_1(); // front montant signal syncho envoi trame
   if (m_pinLedSend != 99)  allumerLedEmission();
   m_xbee.send(m_zbTx);
   viderBufferReceptionPortSerie();
   // délai pour laisser le temps à la carte arduino d'envoyer la trame Tx au module XBee
   //delay((30 + m_zbTx.getPayloadLength()) / 10);
   if (m_pinSend != 99) envoyerSignalSend__mettre_a_0(); // front descendant signal syncho envoi trame
   if (m_pinLedSend != 99)  eteindreLedEmission();

   start = millis(); // mémorise l'instant présent pour laisser le temps à la réponse d'arriver
   //while (int((millis() - start)) < DUREE_ATTENTE_REPONSE); 
   // Module Xbee zbLedCoordi transmet cette trame vers module Xbee zbLedRouteur par ondes radios
   // Attend DUREE_ATTENTE_REPONSE ms max accusé de réception envoyé par module Xbee zbLedRouteur 
   // (instruction bloquante)
   if (m_xbee.readPacket(DUREE_ATTENTE_REPONSE))
   {
      // un accusé de réception a été reçu
      // le paquet reçu doit être une trame ZigBee Transmit Status (0x8B)
      //
      // !!!!! REMARQUE IMPORTANTE !!!!!
      // la fonction readPacket() semble poser problème, le délai entre la détection de réception de la
      // trame réponse et l'envoi effective sur le port serial est très variable. C'est 150 µs ou plus 
      // d'une vingtaine de ms. Ceci dit, la communication fonctionne bien, mais les signaux de synchro
      // peuvent être décalés de plus de 20 ms.
      if (m_xbee.getResponse().getApiId() == ZB_TX_STATUS_RESPONSE)
      {
         if (m_pinReceipt != 99) envoyerSignalReceive__mettre_a_1(); // front mont. signal syncho envoi trame
         // récupère dans la trame les informations utiles pour connaître l'état de la transmission
         m_xbee.getResponse().getZBTxStatusResponse(m_txStatus);
         // récupère l'octet delivery status : 0x00 -> success   0x01 -> MAC ACK Failure  ...
         if (m_txStatus.getDeliveryStatus() == SUCCESS)
         {
            // Transmission effectuée avec succès
            m_errXbeeCode = 0;
            strcpy(m_errXbeeNom, s_AUCUNE_ERR);
         }
         else
         {
            // Erreur lors de la transmission
            m_errXbeeCode = 1;
            strcpy(m_errXbeeNom, s_ERR_XBEE_OFF);
         }
      }
   }
   else if (m_xbee.getResponse().isError())
   {
      // Erreur lors de la transmission
      m_errXbeeCode = 2;
      strcpy(m_errXbeeNom, s_ERR_XBEE_OFF);
   }
   else
   {
      // Erreur lors de la transmission
      m_errXbeeCode = 3;
      strcpy(m_errXbeeNom, s_ERR_XBEE_OFF);
   }
   // attente bloquante de DUREE_ATTENTE_REPONSE pour laisser le temps à la réponse de venir
   if (m_pinReceipt != 99) envoyerSignalReceive__mettre_a_0(); // front desc. signal syncho envoi trame
   signalerErreurCommunication(); // allume led Erreur Communication Xbee en cas d'erreur
}

//-------------------------------------------------------------------------------------------------
// Réceptionne une trame API de type ZBTxRequest, récupère les données utiles puis envoie un 
// accusé de réception. Signale les éventuelles erreurs qui se sont produites lors des échanges
// Réponse stockée dans objet m_rx (ZBRxResponse)
//-------------------------------------------------------------------------------------------------
void XbeeGestion::recevoirAvecZBRxResponseEtEnvoyerAR()
{
   // détecte les paquets reçus s'ils existent, instruction non bloquante
   m_xbee.readPacket();

   if (m_xbee.getResponse().isAvailable())
   {
      // quelque chose est arrivé
      if (m_xbee.getResponse().getApiId() == ZB_RX_RESPONSE)
      {
         m_millisStartDetectPbReceipt = millis(); // débute durée détection erreur sans réception Xbee
         if (m_pinReceipt != 99) envoyerSignalReceive__mettre_a_1(); // front mont. signal syncho envoi trame
         if (m_pinLedReceive != 99)   allumerLedReception();
         // récupère les informations du paquet zb Rx packet
         m_xbee.getResponse().getZBRxResponse(m_rx);

         if (m_rx.getOption() == ZB_PACKET_ACKNOWLEDGED)
         {
            // Succès - l'expéditeur a obtenu un accusé de réception (paquet acquitté)
            m_errXbeeCode = 0;
            strcpy(m_errXbeeNom, s_AUCUNE_ERR);

         }
         else
         {
            // erreur - le paquet a été reçu mais l'expéditeur n'a pas obtenu d'acquittement
            m_errXbeeCode = 4;
            strcpy(m_errXbeeNom, "Paquet reçu sans AR");
         }
         if (m_pinReceipt != 99)  envoyerSignalReceive__mettre_a_0(); // front desc signal syncho envoi trame
         if (m_pinLedReceive != 99)  eteindreLedReception();
      }
      else
      {
         // Erreur - quelque chose d'imprévu !
         m_errXbeeCode = 3;
         strcpy(m_errXbeeNom, s_ERR_XBEE_OFF);
      }
   }
   signalerErreurCommunication(); // allume led Erreur Communication Xbee en cas d'erreur
}

//-------------------------------------------------------------------------------------------------
// Signale une erreur quand aucun paquet Xbee n'a été reçu pendant une durée donnée. Autrement
// dit : durée en ms max entre 2 réceptions de paquet. Lorsque cette durée est dépassée, une erreur
// est signalée.
// Paramètres :
//    dureeMaxSansPaquet -> durée en ms max entre 2 réception de paquets xbee
//-------------------------------------------------------------------------------------------------
void XbeeGestion::signalerProblemeReceptionPaquet(int dureeMaxSansPaquet)
{
   unsigned long millisNow;   // contient nb de millisecondes écoulées à cet instant

   millisNow = millis(); // lit nb de millisecondes écoulées à cet instant
   if (millisNow - m_millisStartDetectPbReceipt > dureeMaxSansPaquet)
   {
      m_errXbeeCode = 9;
      strcpy(m_errXbeeNom, s_ERR_RECEPTION);
   }
   signalerErreurCommunication();
}

//-------------------------------------------------------------------------------------------------
// Vide le buffer de réception du port série connecté au Xbee
//-------------------------------------------------------------------------------------------------
void XbeeGestion::viderBufferReceptionPortSerie()
{
   for (int i = 0; i < 3; i++)
   {  
      if (m_portSerieXbee == 0)
      {
         while (Serial.available() > 0)
         {
            char t = Serial.read();
         }
         delay(1);
      }
      else
      {
         while (Serial1.available() > 0)
         {
            char t = Serial1.read();
         }
         delay(1);
      }
   }
}

//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
void XbeeGestion::effacerData()
{
   for (int i = 0; i < DATA_SIZE_RX; i++)
   {
      m_dataRxOctet[i] = 0;
      m_dataRxChainHex[i] = 0;
   }
   m_nbDataRxOctet = 0;
   m_nbDataRxChainHex = 0;
   m_errXbeeCode = 0;
   strcpy(m_errXbeeNom, s_AUCUNE_ERR);
}

//-------------------------------------------------------------------------------------------------
// Signale une erreur dans la communication
//-------------------------------------------------------------------------------------------------
void XbeeGestion::signalerErreurCommunication()
{
   if (m_errXbeeCode != 0)
      allumerLedErreurXbee();
   else
      eteindreLedErreurXbee();
}

//-------------------------------------------------------------------------------------------------
// Signaux de synchro possibles pour chaque envoi de trame : front montant, descendant ou un 
// basculement à chaque appel
//-------------------------------------------------------------------------------------------------
void XbeeGestion::envoyerSignalSend__mettre_a_1()
{
   digitalWrite(m_pinSend, 1); // envoie un front montant
}

void XbeeGestion::envoyerSignalSend__mettre_a_0()
{
   digitalWrite(m_pinSend, 0); // envoie un front descendant
}

void XbeeGestion::envoyerSignalSend__basculer()
{
   digitalWrite(m_pinSend, !digitalRead(m_pinSend)); // bascule, change l'état logique
}

//-------------------------------------------------------------------------------------------------
// Signaux de synchro possibles pour chaque réception de trame : front montant, descendant ou un 
// basculement à chaque appel
//-------------------------------------------------------------------------------------------------
void XbeeGestion::envoyerSignalReceive__mettre_a_1()
{
   digitalWrite(m_pinReceipt, 1); // envoie un front montant
}

void XbeeGestion::envoyerSignalReceive__mettre_a_0()
{
   digitalWrite(m_pinReceipt, 0); // envoie un front descendant
}

void XbeeGestion::envoyerSignalReceive__basculer()
{
   digitalWrite(m_pinReceipt, !digitalRead(m_pinSend)); // bascule, change l'état logique
}

//-------------------------------------------------------------------------------------------------
// allume la led émission
//-------------------------------------------------------------------------------------------------
void XbeeGestion::allumerLedEmission()
{
   digitalWrite(m_pinLedSend, 1);  // allume la led
   delay(1);   // pour voir la led s'alllumer
}

//-------------------------------------------------------------------------------------------------
// éteint la led émission
//-------------------------------------------------------------------------------------------------
void XbeeGestion::eteindreLedEmission()
{
   digitalWrite(m_pinLedSend, 0);  // allume la led
}

//-------------------------------------------------------------------------------------------------
// change d'état la led émission
//-------------------------------------------------------------------------------------------------
void XbeeGestion::changerEtatLedEmission()
{
   digitalWrite(m_pinLedSend, !digitalRead(m_pinLedSend));  // lit état Led puis prend l'autre état
}

//-------------------------------------------------------------------------------------------------
// allume la led réception
//-------------------------------------------------------------------------------------------------
void XbeeGestion::allumerLedReception()
{
   digitalWrite(m_pinLedReceive, 1);  // allume la led
   delay(1);   // pour voir la led s'alllumer
}

//-------------------------------------------------------------------------------------------------
// éteint la led réception
//-------------------------------------------------------------------------------------------------
void XbeeGestion::eteindreLedReception()
{
   digitalWrite(m_pinLedReceive, 0);  // allume la led
}

//-------------------------------------------------------------------------------------------------
// change d'état la led réception
//-------------------------------------------------------------------------------------------------
void XbeeGestion::changerEtatLedReception()
{
   // lit état Led puis prend l'autre état
   digitalWrite(m_pinLedReceive, !digitalRead(m_pinLedReceive));
}

//-------------------------------------------------------------------------------------------------
// allume la led erreur communication xbee
//-------------------------------------------------------------------------------------------------
void XbeeGestion::allumerLedErreurXbee()
{
   digitalWrite(m_pinLedError, 1);  // allume la led
   delay(1);   // pour voir la led s'alllumer
}

//-------------------------------------------------------------------------------------------------
// éteint la led erreur communication xbee
//-------------------------------------------------------------------------------------------------
void XbeeGestion::eteindreLedErreurXbee()
{
   digitalWrite(m_pinLedError, 0);  // allume la led
}

//-------------------------------------------------------------------------------------------------
// change d'état la erreur communication zigbee
//-------------------------------------------------------------------------------------------------
void XbeeGestion::changerEtatLedErreurXbee()
{
   digitalWrite(m_pinLedError, !digitalRead(m_pinLedError));  // lit état Led puis prend l'autre état
}


//-------------------------------------------------------------------------------------------------
// Exécute puis affiche les données retournées par une commande AT
// Paramètres :
//    cmdAt1 -> 1ère lettre commande AT
//    cmdAt2 -> 2ème lettre commande AT
//-------------------------------------------------------------------------------------------------
void XbeeGestion::executerCommandeAT(uint8_t cmdAt1, uint8_t cmdAt2)
{
   char buffer12[12] = { 0 };     // chaine de caractères contenant réponse à commande AT
   char * pChaine = buffer12;  // pointeur sur la chaine de caractères précédente
   uint8_t isDataNb = false;

   if (cmdAt1 == 'N' && cmdAt2 == 'I')
      isDataNb = false;
   else
      isDataNb = true;

   // Affiche la commande AT demandée
   Serial.print("AT "); Serial.print((char)cmdAt1); Serial.print((char)cmdAt2); Serial.print(" : ");

   // Interroge module Xbee local à l'aide de commande AT puis affiche certains de ses paramètres
   setCommandeAt(cmdAt1, cmdAt2);
   envoyerCmdATetGererReponse();
   if (getErreurXbeeCode() == 0)
   {
      // pas d'erreur détectée
      if (isDataNb)
      {
         // Récupère à l'aide d'un pointeur chaine de caractères contenant réponse à commande AT
         pChaine = getDataHexChain();
         Serial.println(pChaine);
      }
      else
      {
         for (int i = 0; i < getNbDataOctet(); i++)
            Serial.print((char)getDataOctet(i));
         Serial.println("");
      }
   }
   else
   {
      // erreur détectée
      Serial.print("Erreur !!! code : ");
      Serial.println(getErreurXbeeCode());
   }
}

//-------------------------------------------------------------------------------------------------
// Exécute puis affiche les données retournées par une commande AT
// Paramètres :
//    cmdAt1 -> 1ère lettre commande AT
//    cmdAt2 -> 2ème lettre commande AT
//-------------------------------------------------------------------------------------------------
bool XbeeGestion::isError()
{
   if (m_errXbeeCode == 0)
      return 0;
   else
      return 1;
}


//-------------------------------------------------------------------------------------------------
// Lit à l'aide de commandes AT (encapsulés dans trame API) les paramètres du module XBee connecté.
// Utilise le port Serial1 pour communiquer avec le module XBee puis le port Serial0 pour afficher
// les informations dans un terminal.
//-------------------------------------------------------------------------------------------------
void XbeeGestion::afficherInfoXbee()
{
   // affiche la commande AT à exécuter et son résultat
   Serial.println("");
   Serial.println("********** XBee - Networking ********************");
   Serial.println("--- PAN ID -----------------------------");
   executerCommandeAT('I', 'D');
   Serial.println("--- Scan Channnels --------------------------");
   executerCommandeAT('S', 'C');
   Serial.println("--- Channel Verification (1)------------");
   executerCommandeAT('J', 'V');
   Serial.println("--- Join Notification (1)---------------");
   executerCommandeAT('J', 'N');
   Serial.println("--- Operating PAN ID ------------");
   executerCommandeAT('O', 'P');
   Serial.println("--- Operating 16-bit PAN ID ------------");
   executerCommandeAT('O', 'I');
   Serial.println("--- Operating Channel ------------------");
   executerCommandeAT('C', 'H');
   Serial.println("--- Number of remaining end device children ---");
   executerCommandeAT('N', 'C');

   Serial.println("********** XBee - Addressing ********************");
   Serial.println("--- Serial number (local address, 64 bits) -");
   executerCommandeAT('S', 'H');
   executerCommandeAT('S', 'L');
   Serial.println("--- 16 bit Network Address -------------");
   executerCommandeAT('M', 'Y');
   Serial.println("--- Destination Address (64 bits) --");
   executerCommandeAT('D', 'H');
   executerCommandeAT('D', 'L');
   Serial.println("--- Node Identifier --------------------");
   executerCommandeAT('N', 'I');

   Serial.println("********** XBee - RF Interfacing ********************");
   Serial.println("--- Power level (max = 4) --------------");
   executerCommandeAT('P', 'L');


   Serial.println("********** XBee - Serial Interfacing ********************");
   Serial.println("--- Baud Rate --------------------------");
   executerCommandeAT('B', 'D');
   switch (getDataOctet(3))
   {
   case 0:  Serial.print(1200); break;
   case 1:  Serial.print(2400); break;
   case 2:  Serial.print(4800); break;
   case 3:  Serial.print(9600); break;
   case 4:  Serial.print(19200); break;
   case 5:  Serial.print(38400); break;
   case 6:  Serial.print(57600); break;
   case 7:  Serial.print(115200); break;
   default: Serial.print(0);
   }
   Serial.println(" baud");
   Serial.println("--- Parity (0)--------------------------");
   executerCommandeAT('N', 'B');
   Serial.println("--- Stop Bits (0)-----------------------");
   executerCommandeAT('S', 'B');
   Serial.println("--- DIO7 Configuration (0 : disable) ---");
   executerCommandeAT('D', '7');
   Serial.println("--- DIO6 Configuration (0 : disable) ---");
   executerCommandeAT('D', '6');
   Serial.println("--- API Output Mode (2)-----------------");
   executerCommandeAT('A', 'P');

   Serial.println("********** XBee - Diagnostic Commands ********************");
   Serial.println("--- Firmware Version ----------------");
   executerCommandeAT('V', 'R');
   Serial.println("--- Hardware Version ----------------");
   executerCommandeAT('H', 'V');
   Serial.println("--- RSSI of Last Packet ----------------");
   executerCommandeAT('D', 'B');
   Serial.println("--- Supply voltage (V) ----------------");
   Serial.println("  Uxbee en mV = (%V) * (1200 / 1024)");
   executerCommandeAT('%', 'V');
   Serial.println("");
}

//-------------------------------------------------------------------------------------------------
// Affiche la trame envoyée par le module XBee distant, donc réceptionnée par le XBee local
// (XBee distant répond à une trame API envoyée juste avant par le XBee local)
//-------------------------------------------------------------------------------------------------
void XbeeGestion::afficherTrameZBTxStatusResponse()
{
   Serial.println("");
   Serial.println("--- Trame reponse ZBTxStatusResponse (0x8B) en hexa) -----------------");

   // ZB_TX_STATUS_RESPONSE = 0x8B
   if (m_xbee.getResponse().getApiId() == ZB_TX_STATUS_RESPONSE)
   {
      Serial.print("7E"); Serial.print(" ");
      Serial.print(m_txStatus.getMsbLength(), HEX); Serial.print(" ");
      Serial.print(m_txStatus.getLsbLength(), HEX); Serial.print(" ");
      Serial.print(m_txStatus.getApiId(), HEX); Serial.print(" ");
      Serial.print(m_txStatus.getFrameId(), HEX); Serial.print(" ");
      for (unsigned char i = 1; i < m_txStatus.getFrameDataLength(); i++)
      {
         Serial.print(m_txStatus.getFrameData()[i], HEX);
         Serial.print(" ");
      }
      Serial.print(m_txStatus.getChecksum(), HEX); Serial.print(" ");

      Serial.println("");
      Serial.print("Start delimiter : "); Serial.println("7E");
      Serial.print("Length : "); Serial.print(m_txStatus.getMsbLength(), HEX);
      Serial.print(" "); Serial.println(m_txStatus.getLsbLength(), HEX);
      Serial.print("Frame type : "); Serial.print(m_txStatus.getApiId(), HEX);
      Serial.println("   (Transmit Status = 0x8B)");
      Serial.print("Frame ID : "); Serial.println(m_txStatus.getFrameId(), HEX);
      Serial.print("16-bit dest address : "); Serial.print(m_txStatus.getFrameData()[1], HEX);
      Serial.print(" "); Serial.println(m_txStatus.getFrameData()[2], HEX);
      Serial.print("Tx. retry count : "); Serial.println(m_txStatus.getFrameData()[3], HEX);
      Serial.print("Delivery status : "); Serial.print(m_txStatus.getFrameData()[4], HEX);
      Serial.println("   (0 : Success)");
      Serial.print("Discovery status : "); Serial.print(m_txStatus.getFrameData()[5], HEX);
      Serial.println("   (0 : No discovery overhead)");
      Serial.print("Ckecksum : "); Serial.println(m_txStatus.getChecksum(), HEX);
      Serial.print("                 isSuccess : "); Serial.println(m_txStatus.isSuccess(), HEX);
   }
   Serial.println("--- FIN trame reponse ZBTxStatusResponse------------------------------");
   Serial.println("");
}

//-------------------------------------------------------------------------------------------------
// Affiche la trame API de type ZBTxRequest réceptionnée, rponse stockée dans objet m_rx 
// (ZBRxResponse)
//-------------------------------------------------------------------------------------------------
void XbeeGestion::afficherTrameZBRxResponse()
{
   Serial.println("");
   Serial.println("--- Trame reponse ZBRxResponse (0x90) en hexa ------------------------");
   // ZB_RX_RESPONSE = 0x90
   if (m_xbee.getResponse().getApiId() == ZB_RX_RESPONSE)
   {
      Serial.print("7E"); Serial.print(" ");
      Serial.print(m_rx.getMsbLength(), HEX); Serial.print(" ");
      Serial.print(m_rx.getLsbLength(), HEX); Serial.print(" ");
      Serial.print(m_rx.getApiId(), HEX); Serial.print(" ");
      for (int i = 0; i < m_rx.getFrameDataLength(); i++)
      {
         Serial.print(m_rx.getFrameData()[i], HEX);
         Serial.print(" ");
      }
      Serial.print(m_rx.getChecksum(), HEX); Serial.print(" ");

      Serial.println("");
      Serial.print("Start delimiter : "); Serial.println("7E");
      Serial.print("Length : "); Serial.print(m_rx.getMsbLength(), HEX);
      Serial.print(" "); Serial.println(m_rx.getLsbLength(), HEX);
      Serial.print("Frame type : "); Serial.print(m_rx.getApiId(), HEX);
      Serial.println("   (Receive Packet = 0x90)");
      Serial.print("64-bit dest address : ");
      for (int i = 0; i < 8; i++)
      {
         Serial.print(m_rx.getFrameData()[i], HEX);
         Serial.print(" ");
      }
      Serial.println("");
      Serial.print("16-bit dest address : "); Serial.print(m_rx.getFrameData()[8], HEX);
      Serial.print(" "); Serial.println(m_rx.getFrameData()[9], HEX);
      Serial.print("Receive options : "); Serial.println(m_rx.getFrameData()[10], HEX);
      Serial.print("RF Data : ");
      for (int i = 11; i < m_rx.getFrameDataLength(); i++)
      {
         Serial.print(m_rx.getFrameData()[i], HEX);
         Serial.print(" ");
      }
      Serial.println("");
      Serial.print("Ckecksum : "); Serial.println(m_rx.getChecksum(), HEX);
   }
   Serial.println("--- FIN trame reponse ZBRxResponse -----------------------------------");
   Serial.println("");
}


//-------------------------------------------------------------------------------------------------
// Affiche la trame envoyée par la carte arduino au module XBee local, qui l'enverra ensuite
// par liaison radio au module XBee distant
//-------------------------------------------------------------------------------------------------
void XbeeGestion::afficherTrameZBTxRequest()
{
   Serial.println("");
   Serial.println("--- Trame requete ZBTxRequest (0x10) en hexa -------------------------");
   // ZB_TX_REQUEST = 0x10
   if (m_zbTx.getApiId() == ZB_TX_REQUEST)
   {
      Serial.print("7E"); Serial.print(" ");
      Serial.print("00"); Serial.print(" ");
      Serial.print(m_zbTx.getFrameDataLength() + 2, HEX); Serial.print(" ");
      Serial.print(m_zbTx.getApiId(), HEX); Serial.print(" ");
      Serial.print(m_zbTx.getFrameId(), HEX); Serial.print(" ");
      Serial.print(" ");
      for (uint8_t i = 0; i < ZB_TX_API_LENGTH + m_zbTx.getPayloadLength(); i++)
      {
         Serial.print(m_zbTx.getFrameData(i), HEX); Serial.print(" ");
      }
      Serial.print(m_xbee.getChecksum(), HEX);
      Serial.println("");
      
      Serial.print("Start delimiter : "); Serial.println("7E");
      Serial.print("Length : "); Serial.print("00"); 
      Serial.print(" "); Serial.println(m_zbTx.getFrameDataLength() + 2, HEX);
      Serial.print("Frame type : "); Serial.println(m_zbTx.getApiId(), HEX);
      Serial.print("Frame ID : "); Serial.println(m_zbTx.getFrameId(), HEX);
      Serial.print("64-bit dest. address : "); 
      for (uint8_t i = 0; i < 8; i++)
      {
         Serial.print(m_zbTx.getFrameData(i), HEX); Serial.print(" ");
      }
      Serial.println("");
      Serial.print("16-bit dest address : "); Serial.print(m_zbTx.getFrameData(8), HEX); 
      Serial.print(" "); Serial.println(m_zbTx.getFrameData(9), HEX);
      Serial.print("Broadcast radius : "); Serial.println(m_zbTx.getFrameData(10), HEX);
      Serial.print("Options : "); Serial.println(m_zbTx.getFrameData(11), HEX);
      Serial.print("RF date : ");
      for (uint8_t i = 12; i < ZB_TX_API_LENGTH + m_zbTx.getPayloadLength(); i++)
      {
         Serial.print(m_zbTx.getFrameData(i), HEX); Serial.print(" ");
      }
      Serial.println("");
      Serial.print("Ckecksum : "); Serial.println(m_xbee.getChecksum(), HEX);
   }
   Serial.println("--- Fin trame requete ZBTxRequest ---------------------------------");
   Serial.println("");
}

//-------------------------------------------------------------------------------------------------
// Lit à l'aide de commandes AT (encapsulés dans trame API) les paramètres du module XBee connecté.
// Utilise le port Serial1 pour communiquer avec le module XBee puis le port Serial0 pour afficher
// les informations dans un terminal.
//-------------------------------------------------------------------------------------------------
void XbeeGestion::afficherVariableMembre()
{
   Serial.println("");
   Serial.println("********** Variables membres objet XBeeGestion ***********************");
   Serial.print("m_myAddrMsb (DH) : "); Serial.println(m_myAddrMsb, HEX);
   Serial.print("m_myAddrLsb (DL) : "); Serial.println(m_myAddrLsb, HEX);
   Serial.print("m_errXbeeCode (hexa) : "); Serial.println(m_errXbeeCode, HEX);
   Serial.print("m_errXbeeNom : ");
   int i = 0;
   while (m_errXbeeNom[i] != '\0')
   {
      Serial.print(m_errXbeeNom[i]);
      i++;
   }
   Serial.println("");
   Serial.print("m_millisStartDetectPbReceipt : "); 
   Serial.println(m_millisStartDetectPbReceipt, HEX);
   Serial.print("m_pinLedSend : "); Serial.println(m_pinLedSend);
   Serial.print("m_pinLedReceive : "); Serial.println(m_pinLedReceive);
   Serial.print("m_pinLedError : "); Serial.println(m_pinLedError);
   Serial.print("m_pinSend : "); Serial.println(m_pinSend);
   Serial.print("m_pinReceipt : "); Serial.println(m_pinReceipt);
   Serial.println("");

   Serial.println("--- objet m_zbTx (ZBTxRequest) ----------");
   Serial.print("adresse 64 destination Msb : ");
   Serial.println(m_zbTx.getAddress64().getMsb(), HEX);
   Serial.print("adresse 64 destination Lsb :");
   Serial.println(m_zbTx.getAddress64().getLsb(), HEX);
   Serial.print("longueur payload (octets) : ");
   Serial.println(m_zbTx.getPayloadLength());
   Serial.print("payload (hexa) : ");
   for (int i = 0; i < m_zbTx.getPayloadLength(); i++)
   {
      Serial.print(m_zbTx.getPayload()[i], HEX); Serial.print(" ");
   }
   Serial.println("");
   Serial.print("payload (decimal) : ");
   for (int i = 0; i < m_zbTx.getPayloadLength(); i++)
   {
      Serial.print(m_zbTx.getPayload()[i]); Serial.print(" ");
   }
   Serial.println(""); Serial.println("");

   Serial.println("--- objet m_rx (ZBRxResponse) ----------");
   Serial.print("64-bit dest address : ");
   for (int i = 0; i < 8; i++)
   {
      Serial.print(m_rx.getFrameData()[i], HEX);
      Serial.print(" ");
   }
   Serial.println("");
   Serial.print("16-bit dest address : "); Serial.print(m_rx.getFrameData()[8], HEX);
   Serial.print(" "); Serial.println(m_rx.getFrameData()[9], HEX);
   Serial.print("Receive options : "); Serial.println(m_rx.getFrameData()[10], HEX);
   Serial.print("RF Data : ");
   for (int i = 11; i < m_rx.getFrameDataLength(); i++)
   {
      Serial.print(m_rx.getFrameData()[i], HEX);
      Serial.print(" ");
   }
   Serial.println(""); Serial.println("");

   Serial.println("--- objet m_txStatus (ZBTxStatusResponse) ----------");
   Serial.print("Length : "); Serial.print(m_txStatus.getMsbLength(), HEX);
   Serial.print(" "); Serial.println(m_txStatus.getLsbLength(), HEX);
   Serial.print("Frame type : "); Serial.print(m_txStatus.getApiId(), HEX);
   Serial.println("   (8B : Transmit Status)");
   Serial.print("16-bit dest address : "); Serial.print(m_txStatus.getFrameData()[1], HEX);
   Serial.print(" "); Serial.println(m_txStatus.getFrameData()[2], HEX);
   Serial.print("Delivery status : "); Serial.print(m_txStatus.getFrameData()[4], HEX);
   Serial.println("   (0 : Success)");
   Serial.println("********** Fin variables membres objet XBeeGestion *******************");
   Serial.println("");
}

/*
//-------------------------------------------------------------------------------------------------
// Envoie une commande AT au module XBee local pour le configurer
// Retour :
//    uint8_t -> code erreur retourné lors de la réponse du module XBee ou suite à l'émission
//                0 : pas d'erreur     1 ou plus : erreur
//-------------------------------------------------------------------------------------------------
void XbeeGestion::ulongToChaineHex(uint32_t nombre, char * buffer)
{
if (nombre <= 0xFF)
sprintf(buffer, "%02lux", nombre);   // octet -> 0 à 255 (0xFF)
else if (nombre <= 0xFFF)
sprintf(buffer, "%03lx", nombre);
else if (nombre <= 0xFFFF)
sprintf(buffer, "%04lx", nombre);
}
*/