How To Guides
=============

.. toctree::
   :maxdepth: 2
   :titlesonly:

   custom_checkers
   plugins
   transform_plugins
