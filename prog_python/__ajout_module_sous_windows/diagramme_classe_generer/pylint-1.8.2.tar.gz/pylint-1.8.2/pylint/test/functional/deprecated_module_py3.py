"""Test deprecated modules."""
# pylint: disable=unused-import

import optparse # [deprecated-module]
